# Household tasks

A local CLI for recurring chores. Requires Python 3.10+ with SQLite support;
no runtime dependencies or network access.

Run from this directory:

```bash
python3 household_tasks.py add "Wash bedding" --every 7
python3 household_tasks.py add "Change filter" --every 90 --due 2026-10-10
python3 household_tasks.py list
python3 household_tasks.py due
python3 household_tasks.py complete 1
python3 household_tasks.py history 1
python3 household_tasks.py --help
```

Tasks receive numeric IDs. New tasks default to being due today. A task is due
when its next due date is on or before the date being checked. Completion resets
its next due date to **completion date + interval days**; missed intervals do not
accumulate. Intervals are fixed calendar days, not months. Completion dates use
the machine's local calendar date; no times or time zones are stored.

Use `complete ID --on YYYY-MM-DD` to backfill. Future completions and dates on or
before the latest completion are rejected. Completing early is allowed. Every
accepted completion is retained in `history`. `list --on YYYY-MM-DD` and
`due --on YYYY-MM-DD` evaluate the current schedule on another date; they do not
reconstruct historical schedules.

Data defaults to `~/.household_tasks/tasks.sqlite3`. Set `HOUSEHOLD_TASKS_DB` or
put `--db PATH` **before** the subcommand to choose another location. Parent
directories are created automatically. Writes are transactional; simultaneous
writers wait up to five seconds. Back up the database when no command is running.
Errors print to stderr and return a nonzero exit status.

An isolated, repeatable demo (writes only under this repository):

```bash
python3 household_tasks.py --db demo.sqlite3 add "Vacuum" --every 7 --due 2024-01-01
python3 household_tasks.py --db demo.sqlite3 due --on 2024-01-01
python3 household_tasks.py --db demo.sqlite3 complete 1 --on 2024-01-02
python3 household_tasks.py --db demo.sqlite3 list --on 2024-01-08
python3 household_tasks.py --db demo.sqlite3 due --on 2024-01-09
python3 household_tasks.py --db demo.sqlite3 history 1
```

Use a fresh database for each demo to get task ID 1.

Run automated CLI tests and lint (flake8 is a development dependency):

```bash
bash scripts/test.sh
```

The tests use temporary databases and separate CLI processes. They cover
persistence, recurrence boundaries, leap dates, history, defaults, multiple
tasks, invalid inputs, rejected mutations, corrupt databases and date overflow.
See [implementation decision](documentation/implementation.md) for workflow and
technology selection.
