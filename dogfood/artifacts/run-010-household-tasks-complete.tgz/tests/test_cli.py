"""Exercise the actual CLI in separate processes and isolated databases."""

from datetime import date, timedelta
import os
from pathlib import Path
import sqlite3
import subprocess
import sys
import tempfile
import unittest


APP = Path(__file__).resolve().parents[1] / 'household_tasks.py'


class CliTests(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory()
        self.addCleanup(self.directory.cleanup)
        self.db = Path(self.directory.name) / 'nested' / 'tasks.sqlite3'

    def run_cli(self, *args, success=True):
        result = subprocess.run(
            [sys.executable, str(APP), '--db', str(self.db), *args],
            capture_output=True, text=True, timeout=10)
        if success:
            self.assertEqual(result.returncode, 0, result.stderr)
        else:
            self.assertNotEqual(result.returncode, 0)
            self.assertNotIn('Traceback', result.stderr)
        return result

    def test_full_lifecycle_and_persistence(self):
        self.assertIn('No tasks.', self.run_cli('list').stdout)
        self.run_cli('add', 'Clean kitchen', '--every', '7',
                     '--due', '2024-02-28')
        self.assertIn('No due tasks.', self.run_cli(
            'due', '--on', '2024-02-27').stdout)
        self.assertIn('Clean kitchen', self.run_cli(
            'due', '--on', '2024-02-28').stdout)
        self.assertIn('2024-03-07', self.run_cli(
            'complete', '1', '--on', '2024-02-29').stdout)
        listing = self.run_cli('list', '--on', '2024-03-06').stdout
        self.assertIn('2024-02-29\t2024-03-07\tscheduled', listing)
        self.assertIn('No due tasks.', self.run_cli(
            'due', '--on', '2024-03-06').stdout)
        self.assertIn('Clean kitchen', self.run_cli(
            'due', '--on', '2024-03-07').stdout)
        self.run_cli('complete', '1', '--on', '2024-03-10')
        self.assertEqual('2024-02-29\n2024-03-10\n',
                         self.run_cli('history', '1').stdout)
        self.assertIn('2024-03-17', self.run_cli('list').stdout)

    def test_invalid_inputs_do_not_create_database(self):
        cases = [
            ('add', '', '--every', '7'),
            ('add', 'bad\nname', '--every', '7'),
            ('add', 'Laundry', '--every', '0'),
            ('add', 'Laundry', '--every', '-1'),
            ('add', 'Laundry', '--every', 'abc'),
            ('add', 'Laundry', '--every', '1', '--due', '2024-02-30'),
            ('list', '--on', '20240229'),
            ('complete', '0'),
        ]
        for args in cases:
            with self.subTest(args=args):
                self.run_cli(*args, success=False)
                self.assertFalse(self.db.exists())

    def test_rejected_completion_preserves_history(self):
        self.run_cli('add', 'Laundry', '--every', '2')
        self.run_cli('complete', '1', '--on', '2024-01-02')
        for day in ('2024-01-02', '2024-01-01',
                    (date.today() + timedelta(days=1)).isoformat()):
            self.run_cli('complete', '1', '--on', day, success=False)
        self.assertEqual('2024-01-02\n',
                         self.run_cli('history', '1').stdout)
        self.run_cli('complete', '999', success=False)
        self.run_cli('history', '999', success=False)

    def test_multiple_tasks_and_parameterized_names(self):
        self.run_cli('add', "Wash ' dishes; DROP TABLE tasks;", '--every', '1',
                     '--due', '2024-01-01')
        self.run_cli('add', 'Vacuum', '--every', '3', '--due', '2024-01-05')
        output = self.run_cli('due', '--on', '2024-01-01').stdout
        self.assertIn('Wash', output)
        self.assertNotIn('Vacuum', output)
        self.assertIn('Vacuum', self.run_cli('list').stdout)
        self.assertIn('No completions.', self.run_cli('history', '2').stdout)

    def test_default_dates_and_environment_path(self):
        env = dict(os.environ, HOUSEHOLD_TASKS_DB=str(self.db))
        result = subprocess.run(
            [sys.executable, str(APP), 'add', 'Dust', '--every', '1'],
            env=env, capture_output=True, text=True, timeout=10)
        self.assertEqual(0, result.returncode, result.stderr)
        self.assertIn(str(date.today()), self.run_cli('list').stdout)
        self.assertIn(str(date.today()),
                      self.run_cli('complete', '1').stdout)

    def test_unusable_database_and_unsupported_version(self):
        self.db.parent.mkdir(parents=True)
        self.db.write_text('broken database')
        self.run_cli('list', success=False)
        self.assertEqual('broken database', self.db.read_text())
        self.db.unlink()
        with sqlite3.connect(self.db) as conn:
            conn.execute('PRAGMA user_version = 999')
        self.run_cli('list', success=False)
        with sqlite3.connect(self.db) as conn:
            self.assertEqual(999, conn.execute(
                'PRAGMA user_version').fetchone()[0])

    def test_overflow_does_not_save_task(self):
        self.run_cli('add', 'Impossible', '--every', '999999999999',
                     success=False)
        self.assertIn('No tasks.', self.run_cli('list').stdout)
        self.run_cli('add', 'Edge', '--every', '1', '--due', '9999-12-31',
                     success=False)
        self.assertIn('No tasks.', self.run_cli('list').stdout)


if __name__ == '__main__':
    unittest.main()
