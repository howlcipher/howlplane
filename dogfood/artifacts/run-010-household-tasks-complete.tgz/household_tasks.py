#!/usr/bin/env python3
"""Local recurring household tasks with transactional completion history."""

import argparse
from contextlib import closing
from datetime import date, timedelta
import os
from pathlib import Path
import sqlite3
import sys


SCHEMA = """
CREATE TABLE IF NOT EXISTS tasks (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    interval_days INTEGER NOT NULL CHECK(interval_days > 0),
    first_due TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS completions (
    id INTEGER PRIMARY KEY,
    task_id INTEGER NOT NULL REFERENCES tasks(id),
    completed_on TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS completion_task_date
ON completions(task_id, completed_on);
"""


def iso_date(value):
    """Require an unambiguous calendar date."""
    try:
        parsed = date.fromisoformat(value)
        if parsed.isoformat() != value:
            raise ValueError
        return parsed
    except ValueError:
        raise argparse.ArgumentTypeError('Use a valid YYYY-MM-DD date.')


def positive_int(value):
    try:
        number = int(value)
        if number <= 0:
            raise ValueError
        return number
    except ValueError:
        raise argparse.ArgumentTypeError('Use a positive integer.')


def task_name(value):
    name = value.strip()
    if not name or any(ord(char) < 32 or ord(char) == 127 for char in name):
        raise argparse.ArgumentTypeError(
            'Task names must be nonempty and contain no control characters.')
    return name


def parser():
    cli = argparse.ArgumentParser(description=__doc__)
    default_db = Path.home() / '.household_tasks' / 'tasks.sqlite3'
    cli.add_argument(
        '--db', type=Path,
        default=Path(os.environ.get('HOUSEHOLD_TASKS_DB', str(default_db))),
        help='SQLite path (or HOUSEHOLD_TASKS_DB). Put before the command.')
    commands = cli.add_subparsers(dest='command', required=True)
    add = commands.add_parser('add', help='Add a recurring task.')
    add.add_argument('name', type=task_name)
    add.add_argument('--every', type=positive_int, required=True,
                     metavar='DAYS')
    add.add_argument('--due', type=iso_date, default=date.today(),
                     help='First due date, default today.')
    for command in ('list', 'due'):
        show = commands.add_parser(command, help=(
            'Show all tasks.' if command == 'list' else 'Show due tasks.'))
        show.add_argument('--on', type=iso_date, default=date.today(),
                          help='Evaluate due status on this date.')
    complete = commands.add_parser('complete', help='Record a completion.')
    complete.add_argument('id', type=positive_int)
    complete.add_argument('--on', type=iso_date, default=date.today(),
                          help='Completion date, default today.')
    history = commands.add_parser('history', help='Show completion history.')
    history.add_argument('id', type=positive_int)
    return cli


def open_database(path):
    path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(path, timeout=5)
    try:
        conn.row_factory = sqlite3.Row
        conn.execute('PRAGMA foreign_keys = ON')
        version = conn.execute('PRAGMA user_version').fetchone()[0]
        if version not in (0, 1):
            raise ValueError('Unsupported database version.')
        if version == 0:
            # Versioned, transactional initial migration; no partial schema.
            conn.executescript('BEGIN;\n' + SCHEMA
                               + '\nPRAGMA user_version = 1;\nCOMMIT;')
        return conn
    except Exception:
        conn.close()
        raise


def get_task(conn, task_id):
    task = conn.execute('SELECT * FROM tasks WHERE id = ?',
                        (task_id,)).fetchone()
    if task is None:
        raise ValueError(f'Task {task_id} does not exist.')
    return task


def next_due(task, last_completed):
    if last_completed is None:
        return date.fromisoformat(task['first_due'])
    return (date.fromisoformat(last_completed)
            + timedelta(days=task['interval_days']))


def execute(conn, args):
    if args.command == 'add':
        # Validate representable recurrence before any mutation.
        args.due + timedelta(days=args.every)
        with conn:
            cursor = conn.execute(
                'INSERT INTO tasks(name, interval_days, first_due) '
                'VALUES (?, ?, ?)',
                (args.name, args.every, args.due.isoformat()))
        print(f'Added task {cursor.lastrowid}: {args.name}')
    elif args.command in ('list', 'due'):
        rows = conn.execute(
            'SELECT t.*, MAX(c.completed_on) AS last_completed '
            'FROM tasks t LEFT JOIN completions c ON c.task_id = t.id '
            'GROUP BY t.id ORDER BY t.id').fetchall()
        lines = []
        for task in rows:
            due = next_due(task, task['last_completed'])
            if args.command == 'due' and due > args.on:
                continue
            status = 'DUE' if due <= args.on else 'scheduled'
            last = task['last_completed'] or 'never'
            lines.append(f"{task['id']}\t{task['name']}\t"
                         f"{task['interval_days']}\t{last}\t{due}\t{status}")
        if lines:
            print('ID\tTASK\tEVERY DAYS\tLAST COMPLETED\tNEXT DUE\tSTATUS')
            print('\n'.join(lines))
        else:
            print('No due tasks.' if args.command == 'due' else 'No tasks.')
    elif args.command == 'complete':
        if args.on > date.today():
            raise ValueError('Completion date cannot be in the future.')
        # Serialize validation and insertion across concurrent processes.
        conn.execute('BEGIN IMMEDIATE')
        with conn:
            task = get_task(conn, args.id)
            last = conn.execute(
                'SELECT MAX(completed_on) FROM completions WHERE task_id = ?',
                (args.id,)).fetchone()[0]
            if last and args.on.isoformat() <= last:
                raise ValueError(
                    'Completion must be after the last completion.')
            due = next_due(task, args.on.isoformat())
            conn.execute('INSERT INTO completions(task_id, completed_on) '
                         'VALUES (?, ?)', (args.id, args.on.isoformat()))
        print(f'Completed task {args.id} on {args.on}; next due {due}.')
    else:
        get_task(conn, args.id)
        rows = conn.execute(
            'SELECT completed_on FROM completions WHERE task_id = ? '
            'ORDER BY completed_on', (args.id,)).fetchall()
        print('\n'.join(row[0] for row in rows) or 'No completions.')


def main(argv=None):
    args = parser().parse_args(argv)
    try:
        with closing(open_database(args.db)) as conn:
            execute(conn, args)
        return 0
    except (OSError, sqlite3.Error, ValueError, OverflowError) as error:
        print(f'Error: {error}', file=sys.stderr)
        return 1


if __name__ == '__main__':
    sys.exit(main())
