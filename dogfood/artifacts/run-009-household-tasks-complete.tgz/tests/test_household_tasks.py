"""CLI acceptance contracts with isolated, real SQLite persistence."""
from concurrent.futures import ThreadPoolExecutor
from datetime import date
import json
from pathlib import Path
import sqlite3
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

import household_tasks


APP = Path(__file__).resolve().parents[1] / 'household_tasks.py'


class HouseholdTasksTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.db = Path(self.temp.name) / 'tasks.db'

    def cli(self, *args, success=True):
        result = subprocess.run(
            [sys.executable, str(APP), '--db', str(self.db), *args],
            capture_output=True, text=True, timeout=10,
        )
        self.assertEqual(result.returncode, 0 if success else 2,
                         result.stderr)
        self.assertNotIn('Traceback', result.stderr)
        self.assertNotIn("can't open file", result.stderr)
        if not success:
            self.assertIn('error', result.stderr.lower())
        return result

    def rows(self, command='list', *args):
        return json.loads(self.cli(command, *args, '--json').stdout)

    def add(self, name='Clean filters', every='7', start='2026-01-01'):
        return self.cli('add', name, '--every', every, '--start', start)

    def test_lifecycle_persists_across_processes_and_retains_history(self):
        self.add()
        self.assertEqual(self.rows()[0]['next_due'], '2026-01-01')
        self.assertEqual(len(self.rows('due', '--on', '2026-01-01')), 1)
        self.cli('complete', '1', '--on', '2026-01-02')
        row = self.rows()[0]
        self.assertEqual(row['last_completed'], '2026-01-02')
        self.assertEqual(row['next_due'], '2026-01-09')
        self.assertEqual(self.rows('due', '--on', '2026-01-08'), [])
        self.assertEqual(len(self.rows('due', '--on', '2026-01-09')), 1)
        self.cli('complete', '1', '--on', '2026-01-10')
        history = self.rows('history', '1')
        self.assertEqual([r['completed_on'] for r in history],
                         ['2026-01-02', '2026-01-10'])
        self.assertEqual(self.rows()[0]['next_due'], '2026-01-17')

    def test_empty_and_help(self):
        self.assertEqual(self.rows(), [])
        self.assertIn('No tasks', self.cli('list').stdout)
        self.assertIn('complete', self.cli('--help').stdout)

    def test_independent_tasks_unicode_and_duplicate_names(self):
        self.add('洗濯 🧺')
        self.add('洗濯 🧺', every='2')
        rows = self.rows()
        self.assertEqual([r['id'] for r in rows], [1, 2])
        self.cli('complete', '2', '--on', '2026-01-01')
        self.assertIsNone(self.rows()[0]['last_completed'])
        self.assertEqual(self.rows()[1]['next_due'], '2026-01-03')

    def test_invalid_inputs_do_not_create_database(self):
        for args in [
            ('add', '  ', '--every', '7'),
            ('add', 'x\nspoof', '--every', '7'),
            ('add', 'x', '--every', '0'),
            ('add', 'x', '--every', '-1'),
            ('add', 'x', '--every', '1.5'),
            ('add', 'x', '--every', '36501'),
            ('add', 'x', '--every', '7', '--start', '2026-02-30'),
            ('add', 'x', '--every', '7', '--start', '20260101'),
            ('complete', '0'),
        ]:
            with self.subTest(args=args):
                self.cli(*args, success=False)
                self.assertFalse(self.db.exists())

    def test_missing_task_and_invalid_completion_do_not_mutate(self):
        self.add()
        for args in [
            ('complete', '99'), ('history', '99'),
            ('complete', '1', '--on', '2025-12-31'),
            ('complete', '1', '--on', '9999-12-31'),
        ]:
            self.cli(*args, success=False)
        self.assertEqual(self.rows('history', '1'), [])
        self.cli('complete', '1', '--on', '2026-01-03')
        self.cli('complete', '1', '--on', '2026-01-02', success=False)
        self.cli('complete', '1', '--on', '2026-01-03', success=False)
        self.assertEqual(len(self.rows('history', '1')), 1)

    def test_future_start_and_calendar_boundaries(self):
        self.add(start='2028-02-28', every='2')
        self.assertEqual(self.rows('due', '--on', '2028-02-27'), [])
        self.assertEqual(len(self.rows('due', '--on', '2028-02-28')), 1)
        self.add('Year boundary', every='2', start='2025-12-31')
        self.cli('complete', '2', '--on', '2025-12-31')
        self.assertEqual(self.rows()[0]['next_due'], '2026-01-02')

    def test_future_completion_rejected_without_recording_completion(self):
        self.add(start='9999-12-31')
        self.cli('complete', '1', '--on', '9999-12-31', success=False)
        self.assertEqual(self.rows('history', '1'), [])

    def test_calendar_overflow_rolls_back_completion(self):
        class EndOfCalendar(date):
            @classmethod
            def today(cls):
                return cls.max

        with sqlite3.connect(':memory:') as conn:
            conn.row_factory = sqlite3.Row
            household_tasks.initialize(conn)
            conn.execute(
                'INSERT INTO tasks VALUES (1, ?, 7, ?, ?)',
                ('Filters', '9999-12-31', '9999-12-31'),
            )
            with patch.object(household_tasks, 'date', EndOfCalendar):
                with self.assertRaisesRegex(ValueError, 'calendar range'):
                    household_tasks.complete_task(conn, 1, date.max)
            self.assertEqual(conn.execute(
                'SELECT COUNT(*) FROM completions').fetchone()[0], 0)
            self.assertEqual(conn.execute(
                'SELECT next_due FROM tasks').fetchone()[0], '9999-12-31')

    def test_corrupt_database_is_not_overwritten(self):
        self.db.write_bytes(b'not a database')
        self.cli('list', success=False)
        self.assertEqual(self.db.read_bytes(), b'not a database')

    def test_unsupported_schema_is_not_modified(self):
        with sqlite3.connect(self.db) as conn:
            conn.execute('PRAGMA user_version = 99')
        self.cli('add', 'x', '--every', '2', success=False)
        with sqlite3.connect(self.db) as conn:
            self.assertEqual(conn.execute('PRAGMA user_version').fetchone()[0],
                             99)

    def test_leap_day_recurrence(self):
        self.add(start='2024-02-28', every='2')
        self.cli('complete', '1', '--on', '2024-02-28')
        self.assertEqual(self.rows()[0]['next_due'], '2024-03-01')

    def test_storage_failure_is_friendly(self):
        self.db = Path(self.temp.name)  # A directory cannot be a database.
        self.cli('list', success=False)

    def test_defaults_use_local_today(self):
        self.cli('add', 'Dishes', '--every', '1')
        self.assertEqual(self.rows()[0]['next_due'], date.today().isoformat())
        self.cli('complete', '1')
        self.assertEqual(self.rows()[0]['last_completed'],
                         date.today().isoformat())

    def test_concurrent_adds_and_duplicate_completion(self):
        def invoke(args):
            return subprocess.run(
                [sys.executable, str(APP), '--db', str(self.db), *args],
                capture_output=True, text=True, timeout=10,
            )

        with ThreadPoolExecutor(max_workers=4) as pool:
            results = list(pool.map(invoke, [
                ['add', f'Chore {i}', '--every', '7',
                 '--start', '2026-01-01'] for i in range(4)
            ]))
        self.assertEqual([r.returncode for r in results], [0] * 4)
        self.assertEqual(len(self.rows()), 4)
        with ThreadPoolExecutor(max_workers=2) as pool:
            results = list(pool.map(invoke, [
                ['complete', '1', '--on', '2026-01-02'] for _ in range(2)
            ]))
        self.assertEqual(sorted(r.returncode for r in results), [0, 2])
        self.assertEqual(len(self.rows('history', '1')), 1)
        self.assertEqual(self.rows()[3]['next_due'], '2026-01-09')

    def test_text_output_and_sql_metacharacters(self):
        self.add("Clean '); DROP TABLE tasks; --")
        self.assertIn('Clean', self.cli('list').stdout)
        self.cli('complete', '1', '--on', '2026-01-01')
        self.assertIn('2026-01-01', self.cli('history', '1').stdout)
        self.assertEqual(len(self.rows()), 1)


if __name__ == '__main__':
    unittest.main()
