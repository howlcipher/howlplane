# Household tasks

A small local CLI for recurring chores. Requires Python 3.10 or newer with
SQLite support. No runtime packages, network access, or server required.

```bash
python3 household_tasks.py --help
python3 household_tasks.py add "Clean filters" --every 7
python3 household_tasks.py list
python3 household_tasks.py due
python3 household_tasks.py complete 1
python3 household_tasks.py history 1
```

Tasks receive stable numeric IDs. Names may repeat; use the ID to complete a
specific task. Lists are sorted by next due date, then ID.

For reproducible dates and a custom database, put `--db` before the command:

```bash
python3 household_tasks.py --db ./data/tasks.sqlite3 add "Clean filters" --every 7 --start 2026-01-01
python3 household_tasks.py --db ./data/tasks.sqlite3 complete 1 --on 2026-01-02
python3 household_tasks.py --db ./data/tasks.sqlite3 due --on 2026-01-09 --json
python3 household_tasks.py --db ./data/tasks.sqlite3 history 1 --json
```

`list`, `due`, and `history` support `--json` for scripts. Empty JSON output is
`[]`. Successful commands exit 0; invalid input, unknown IDs, and storage errors
exit 2 with an error on stderr.

## Recurrence and completion

`--every` is a whole number of calendar days from 1 to 36500. A new task is due
on `--start`, which defaults to the computer's local current date. Future start
dates are allowed. A task is due when its next due date is on or before today,
or the date supplied to `due --on`.

Completing a task records `--on` (default: today) in its permanent history and
sets its next due date to that completion date plus the recurrence interval.
Early completion is allowed after the first due date. Missed periods do not
produce multiple overdue entries. Dates use `YYYY-MM-DD`; completion dates
cannot be in the future, before the first due date, or on/before the latest
completion. At most one completion per task per day is supported.

`due --on` compares against the current schedule; it does not reconstruct a
historical schedule. Completion records contain dates, not clock times.

## Storage and verification

The default database is `~/.household_tasks/tasks.sqlite3`. Parent directories
are created automatically. SQLite transactions protect completion history and
schedule updates together, and concurrent CLI writes are serialized with a
five-second lock timeout. The store is local and unencrypted: protect it with
filesystem permissions. Back it up while the CLI is idle. Unsupported database
versions and corrupt stores fail without being overwritten.

```bash
bash scripts/test.sh
bash scripts/lint.sh   # requires flake8 (development tool only)
bash scripts/demo.sh   # isolated temporary database, cleaned on exit
```

See [the implementation decision and workflow evidence](documentation/implementation.md).
