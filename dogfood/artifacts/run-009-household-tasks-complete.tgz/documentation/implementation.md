# Implementation and verification journal

## Objective and context

Build a local recurring household task CLI with add, list, complete, recorded
completion dates, due detection, persistence, automated tests, and concise docs.
Initial inspection found a clean Git working tree with only a placeholder
README, and empty local `.agents` and `.codex` directories. No partial
implementation existed.

Workflow references came from the installed HowlPlane library:
`documentation/CONTROL_PLANE.md`, `.agents/prompts/route_task.md`,
`.agents/prompts/review_change.md`, `.agents/prompts/ship_check.md`,
`documentation/TESTING.md`, and the development, architecture, Python,
grounding, debugging, QA, and verification skills. The library rules were read,
including `.agents/rules/anti_manipulation.md`. The user permitted normal
Markdown and required all implementation writes to remain in this repository.

## Routing and approach decision

The normal deterministic router was invoked before implementation:

```bash
howlplane route 'Implement recurring household task management command line application with local persistence' --role implementation --risk low --tier tier_2 --agent codex --semantic off --json
```

Result: feature, implementation role, selected Codex, reasoning tier 2,
explicit current-agent override. The router's default cognitive recommendation
was agy. No remote provider execution was requested.

The first route attempt included the full objective with the word `tests`.
The live router failed with invalid task class `test` (allowed class:
`test_improvement`), diagnostic `HP-20261003-161430-7231`. The implementation
objective above routed successfully. This is a library update candidate for
HowlPlane task classification; no sibling repository was modified.

| Option | Benefits | Costs |
| --- | --- | --- |
| Python standard library | Available locally; argparse, calendar dates, SQLite, unittest; no runtime packages | Requires Python installation |
| Go | Distributable native executable; strong typing | Build step and more date/CLI plumbing for this scope |
| Bash | Direct invocation, little scaffolding | Date portability, validation, and safe persistence are harder |
| HowlFrame | Capability-bounded execution and native record store | Additional compiler/runtime dependency and date integration |
| SQLite persistence | Atomic history/schedule updates, concurrent-write protection, local queries | Store is binary; requires SQLite support and backup care |
| JSON persistence | Human-readable file | Requires explicit locking, atomic replacement, schema validation |

Selected Python with SQLite after context discovery and routing. One small
module separates parsing, persistence, domain rules, and rendering functions.
The application runs directly, without installation or compilation.

## Acceptance and review

Tests were written before the implementation and initially failed because the
application did not yet exist. CLI acceptance tests invoke real subprocesses
with isolated SQLite stores. They cover persistent lifecycle, recurrence,
history, input validation, calendar boundaries, duplicate names, Unicode,
parameterized queries, corrupt/incompatible storage, and concurrent writes.
One in-memory domain test reaches calendar overflow with a controlled clock.

Independent review applied correctness, test-falsification, and simplicity
criteria. The reviewer ran the initial 14 tests, lint, and demo successfully.
Finding R1 (low, confirmed): the original overflow test reached future-date
rejection rather than overflow. Remediated by renaming that contract and adding
a focused overflow test asserting the specific error and unchanged records.
The final suite contains 15 tests. No other runtime defects were reported.
The reviewer could not locate the global prompt/rule through its local lookup;
the implementation agent had already read those installed library references.

Iteration fixes: the date-sorted output required a corrected test index;
flake8 needed `--jobs 1` because sandbox permissions prohibit its default
multiprocessing socket. Line-length errors were corrected without suppressions.

Final regression gate: `bash scripts/test.sh`, `bash scripts/lint.sh`, and
`bash scripts/demo.sh`, plus `git diff --check`. Structured test impact evidence
is in `test_impact.json`, recorded and checked through HowlPlane using the
repository-local `evidence.jsonl`. This scope includes all application tests,
CLI integration, lint, and an independent executable demonstration.

## Boundaries, limitations, and status

All application, documentation, testing, and evidence writes are local to this
workspace. No commit, push, publication, other-worktree mutation, production
operation, destructive migration, paid service, credential provisioning, or
external message is part of the work. No human authority boundary is triggered.

Dates have day precision and use the local computer's current date. There is no
monthly recurrence, edit/delete command, encryption, or historical schedule
reconstruction. The schema is versioned but no migration is needed or provided
for this first version. Disk and permission failures return a friendly error;
users remain responsible for protecting and backing up their local data.

Completion status: complete after the final regression and test impact check.
