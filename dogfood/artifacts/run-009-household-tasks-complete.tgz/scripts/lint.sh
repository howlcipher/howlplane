#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
flake8 --jobs 1 household_tasks.py tests
