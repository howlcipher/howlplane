#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
demo_dir=$(mktemp -d)
trap 'rm -rf -- "$demo_dir"' EXIT
python3 household_tasks.py --db "$demo_dir/tasks.sqlite3" add "Clean filters" --every 7 --start 2026-01-01
python3 household_tasks.py --db "$demo_dir/tasks.sqlite3" list
python3 household_tasks.py --db "$demo_dir/tasks.sqlite3" complete 1 --on 2026-01-02
python3 household_tasks.py --db "$demo_dir/tasks.sqlite3" history 1
python3 household_tasks.py --db "$demo_dir/tasks.sqlite3" due --on 2026-01-08
python3 household_tasks.py --db "$demo_dir/tasks.sqlite3" due --on 2026-01-09
