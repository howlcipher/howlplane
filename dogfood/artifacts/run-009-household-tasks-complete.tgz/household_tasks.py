#!/usr/bin/env python3
"""Manage recurring household tasks using calendar dates and local SQLite."""
import argparse
from contextlib import closing
from datetime import date, timedelta
import json
from pathlib import Path
import sqlite3
import sys
import unicodedata


SCHEMA_VERSION = 1


def calendar_date(value):
    """Accept an unambiguous ISO calendar date, not ISO's compact variants."""
    try:
        parsed = date.fromisoformat(value)
        if parsed.isoformat() != value:
            raise ValueError
        return parsed
    except ValueError:
        raise argparse.ArgumentTypeError('use a valid YYYY-MM-DD date')


def positive_integer(value):
    try:
        number = int(value)
        if number < 1:
            raise ValueError
        return number
    except ValueError:
        raise argparse.ArgumentTypeError('must be a positive integer')


def interval(value):
    number = positive_integer(value)
    if number > 36500:
        raise argparse.ArgumentTypeError('interval must be at most 36500 days')
    return number


def task_name(value):
    name = value.strip()
    if not name or len(name) > 200:
        raise argparse.ArgumentTypeError(
            'name must contain 1 to 200 characters')
    if any(unicodedata.category(char).startswith('C') for char in name):
        raise argparse.ArgumentTypeError(
            'name cannot contain control characters')
    return name


def parser():
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument('--db', type=Path,
                     default=(Path.home() / '.household_tasks'
                              / 'tasks.sqlite3'),
                     help='path (default: ~/.household_tasks/tasks.sqlite3)')
    commands = cli.add_subparsers(dest='command', required=True)
    add = commands.add_parser('add', help='add a recurring task')
    add.add_argument('name', type=task_name)
    add.add_argument('--every', required=True, type=interval,
                     metavar='DAYS', help='repeat every 1 to 36500 days')
    add.add_argument('--start', type=calendar_date, default=date.today(),
                     help='first due date (default: today)')
    for command in ('list', 'due'):
        listing = commands.add_parser(command, help=f'{command} tasks')
        listing.add_argument('--json', action='store_true')
        if command == 'due':
            listing.add_argument('--on', type=calendar_date,
                                 default=date.today(),
                                 help='as of date (default: today)')
    complete = commands.add_parser('complete', help='record a completion')
    complete.add_argument('id', type=positive_integer)
    complete.add_argument('--on', type=calendar_date, default=date.today(),
                          help='completion date (default: today)')
    history = commands.add_parser('history', help='show completion history')
    history.add_argument('id', type=positive_integer)
    history.add_argument('--json', action='store_true')
    return cli


def initialize(conn):
    version = conn.execute('PRAGMA user_version').fetchone()[0]
    if version not in (0, SCHEMA_VERSION):
        raise ValueError('unsupported database version; use a compatible app')
    if version == 0:
        existing = conn.execute(
            "SELECT name FROM sqlite_master WHERE type = 'table'"
        ).fetchall()
        if existing:
            raise ValueError('database is not an empty household tasks store')
        conn.execute('''CREATE TABLE tasks (
            id INTEGER PRIMARY KEY,
            name TEXT NOT NULL,
            interval_days INTEGER NOT NULL
                CHECK(interval_days BETWEEN 1 AND 36500),
            first_due TEXT NOT NULL,
            next_due TEXT NOT NULL
        )''')
        conn.execute('''CREATE TABLE completions (
            id INTEGER PRIMARY KEY,
            task_id INTEGER NOT NULL REFERENCES tasks(id),
            completed_on TEXT NOT NULL,
            UNIQUE(task_id, completed_on)
        )''')
        conn.execute('CREATE INDEX completion_task '
                     'ON completions(task_id, id)')
        conn.execute(f'PRAGMA user_version = {SCHEMA_VERSION}')


def require_task(conn, task_id):
    row = conn.execute('SELECT * FROM tasks WHERE id = ?',
                       (task_id,)).fetchone()
    if row is None:
        raise ValueError(f'task {task_id} does not exist')
    return row


def complete_task(conn, task_id, completed_on):
    task = require_task(conn, task_id)
    latest = conn.execute(
        'SELECT MAX(completed_on) FROM completions WHERE task_id = ?',
        (task_id,),
    ).fetchone()[0]
    if completed_on > date.today():
        raise ValueError('completion date cannot be in the future')
    if completed_on.isoformat() < task['first_due']:
        raise ValueError('completion date cannot precede the first due date')
    if latest and completed_on.isoformat() <= latest:
        raise ValueError('completion date must be after the last completion')
    try:
        next_due = completed_on + timedelta(days=task['interval_days'])
    except OverflowError:
        raise ValueError('next due date would exceed the calendar range')
    conn.execute(
        'INSERT INTO completions(task_id, completed_on) VALUES (?, ?)',
        (task_id, completed_on.isoformat()),
    )
    conn.execute('UPDATE tasks SET next_due = ? WHERE id = ?',
                 (next_due.isoformat(), task_id))
    return f'Completed task {task_id} on {completed_on}; next due {next_due}.'


def task_rows(conn, as_of=None):
    query = '''SELECT t.id, t.name, t.interval_days, t.first_due, t.next_due,
               MAX(c.completed_on) AS last_completed
               FROM tasks t LEFT JOIN completions c ON t.id = c.task_id'''
    values = ()
    if as_of:
        query += ' WHERE t.next_due <= ?'
        values = (as_of.isoformat(),)
    query += ' GROUP BY t.id ORDER BY t.next_due, t.id'
    return [dict(row) for row in conn.execute(query, values)]


def display(rows, as_json, history=False):
    if as_json:
        return json.dumps(rows, ensure_ascii=False, indent=2)
    if not rows:
        return 'No completions.' if history else 'No tasks.'
    if history:
        return '\n'.join(row['completed_on'] for row in rows)
    lines = ['ID\tEvery (days)\tNext due\tLast completed\tTask']
    for row in rows:
        lines.append(f"{row['id']}\t{row['interval_days']}\t"
                     f"{row['next_due']}\t"
                     f"{row['last_completed'] or 'never'}\t{row['name']}")
    return '\n'.join(lines)


def execute(conn, args):
    if args.command == 'add':
        cursor = conn.execute(
            'INSERT INTO tasks(name, interval_days, first_due, next_due) '
            'VALUES (?, ?, ?, ?)',
            (args.name, args.every, args.start.isoformat(),
             args.start.isoformat()),
        )
        return f'Added task {cursor.lastrowid}: {args.name}.'
    if args.command == 'complete':
        return complete_task(conn, args.id, args.on)
    if args.command == 'history':
        require_task(conn, args.id)
        rows = [dict(row) for row in conn.execute(
            'SELECT completed_on FROM completions '
            'WHERE task_id = ? ORDER BY completed_on, id', (args.id,),
        )]
        return display(rows, args.json, history=True)
    as_of = args.on if args.command == 'due' else None
    return display(task_rows(conn, as_of), args.json)


def main(argv=None):
    args = parser().parse_args(argv)
    try:
        args.db.parent.mkdir(parents=True, exist_ok=True)
        with closing(sqlite3.connect(args.db, timeout=5)) as conn:
            conn.row_factory = sqlite3.Row
            conn.execute('PRAGMA foreign_keys = ON')
            # Serialize updates so concurrent completions cannot race.
            conn.execute('BEGIN IMMEDIATE')
            with conn:
                initialize(conn)
                output = execute(conn, args)
        print(output)
        return 0
    except (OSError, sqlite3.Error):
        print('Error: cannot access household tasks database; check the path, '
              'permissions, available space, file integrity and lock status.',
              file=sys.stderr)
    except ValueError as error:
        print(f'Error: {error}', file=sys.stderr)
    return 2


if __name__ == '__main__':
    sys.exit(main())
