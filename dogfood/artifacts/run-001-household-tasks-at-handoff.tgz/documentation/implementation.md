# Implementation decision and evidence

The initial working tree was clean, with only a placeholder README. There were
no partial application changes, local skills, rules, or stack markers.
Shared skills were read through their installed paths. Workflow reference:
`howlplane/documentation/CONTROL_PLANE.md`; routing instructions:
`howlplane/.agents/prompts/route_task.md`; anti-manipulation rules:
`howlplane/.agents/rules/anti_manipulation.md` in the local development library.

## Howl workflow

1. Inspected installed `howl` and `howlplane` command help and the control-plane
   workflow before selecting a stack.
2. Created `task_spec.yaml` using `howlplane init-task --repo "$PWD"`.
   Automatic repository discovery initially failed with “repository must be a
   non-empty string”; the explicit repository argument resolved it. This is a
   library/tooling update candidate, not a reason to modify another repository.
3. Ran `howlplane route` and `howlplane route-task`. Selected implementer:
   Codex, tier_2, low risk. The explicit Codex override preserves the current
   implementation assignment. Recommended review roles: correctness-reviewer,
   test-falsifier, simplicity-reviewer.
4. Compared approaches below, then implemented Python with SQLite.
5. Ran automated CLI tests and lint, recorded the Test Impact Assessment and
   verification evidence in this repository, and checked the authority boundary.

This is a local implementation using the specification, routing, verification,
and evidence stages. It does not claim a nested orchestration session or an
independent agent audit. The implementer reviewed correctness, test gaps, and
simplicity locally.

## Options considered before implementation

| Approach | Benefits | Costs |
| --- | --- | --- |
| Python and SQLite | Standard-library CLI, calendar arithmetic, transactions, easy subprocess tests | Requires Python; no standalone executable |
| Go and SQLite | Standalone executable, static types | SQLite driver adds dependency/build requirements |
| HowlFrame native store | Capability-bounded execution, native record store | Requires compiler/runtime and additional calendar/CLI integration validation |
| Python and JSON | Human-readable storage, minimal persistence code | Requires custom locking and atomic replacement for concurrent writers |

Selected Python and SQLite: they supply all required local capabilities without
runtime packages or custom persistence locking. This selection follows context
inspection and deterministic routing, rather than an assumed HowlFrame mandate.

The application has one CLI module and two tables. Completion events are
append-only; dates are ISO strings, so SQLite's maximum selects the latest date
regardless of insertion order. The initial migration is versioned with
`user_version`, runs automatically in a transaction, and rejects unknown schema
versions. There is no destructive migration or schema downgrade command.

## Verification scope and limitations

The complete regression gate is `bash scripts/test.sh`: subprocess integration
tests plus `python3 -m flake8 --jobs=1 household_tasks tests`. Single-process lint
avoids the sandbox's restriction on worker-process socket creation. The initial
multi-process lint attempt failed for that environment reason; two line-length
errors found in single-process mode were fixed before the final gate.

Tests cover recurring lifecycle and persistence, completion history, leap-year
arithmetic, due boundaries, backdated entries, default dates, empty state,
argument validation, missing IDs, future completions, corrupt/inaccessible
storage, schema-version rejection, parameterized SQL, concurrent first use,
calendar overflow, and CLI help. No pre-existing tests needed updating/removal.

Remaining scope limits: daily intervals only, local single-machine storage,
manual backups, and no task editing/deletion, notifications, or synchronization.
The application stores completion dates and recording timestamps, not the exact
time of performing a chore. Tested on the supplied Linux/Python environment;
other platforms and Python versions have not been executed here.
