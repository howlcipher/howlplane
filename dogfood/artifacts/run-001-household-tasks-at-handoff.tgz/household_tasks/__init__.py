"""Local recurring household task management."""
