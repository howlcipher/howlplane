"""Command line interface with calendar-day recurrence and SQLite storage."""

import argparse
from contextlib import closing
from datetime import date, datetime, timedelta, timezone
import json
from pathlib import Path
import sqlite3
import sys


SCHEMA = """
CREATE TABLE tasks (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    every_days INTEGER NOT NULL CHECK (every_days > 0),
    first_due TEXT NOT NULL
);
CREATE TABLE completions (
    id INTEGER PRIMARY KEY,
    task_id INTEGER NOT NULL REFERENCES tasks(id),
    completed_on TEXT NOT NULL,
    recorded_at TEXT NOT NULL
);
CREATE INDEX completion_task_date ON completions(task_id, completed_on);
PRAGMA user_version = 1;
"""


def calendar_date(value):
    """Require unambiguous ISO calendar dates."""
    try:
        parsed = date.fromisoformat(value)
        if parsed.isoformat() != value:
            raise ValueError
        return parsed
    except ValueError:
        raise argparse.ArgumentTypeError('use a valid YYYY-MM-DD date')


def positive_integer(value):
    try:
        number = int(value)
        if number < 1 or number > 365000:
            raise ValueError
        return number
    except ValueError:
        raise argparse.ArgumentTypeError('use an integer from 1 to 365000')


def task_name(value):
    value = value.strip()
    if not value or len(value) > 200 or any(ord(c) < 32 for c in value):
        raise argparse.ArgumentTypeError(
            'name must contain 1 to 200 characters without control characters')
    return value


def parser():
    result = argparse.ArgumentParser(
        prog='household_tasks',
        description='Manage recurring household tasks.')
    result.add_argument('--db', type=Path, default=Path('data/tasks.sqlite3'),
                        help='local SQLite file (default: data/tasks.sqlite3)')
    commands = result.add_subparsers(dest='command', required=True)
    add = commands.add_parser('add', help='add a recurring task')
    add.add_argument('name', type=task_name)
    add.add_argument('--every', type=positive_integer, required=True,
                     metavar='DAYS')
    add.add_argument('--due', type=calendar_date, default=date.today(),
                     help='first due date; defaults to today')
    for command in ('list', 'due'):
        listing = commands.add_parser(command, help=f'{command} tasks')
        listing.add_argument('--on', type=calendar_date, default=date.today(),
                             help='evaluate due status on this date')
    complete = commands.add_parser('complete', help='record a completion')
    complete.add_argument('id', type=positive_integer)
    complete.add_argument('--on', type=calendar_date, default=date.today(),
                          help='completion date; defaults to today')
    history = commands.add_parser('history', help='show completion history')
    history.add_argument('id', type=positive_integer)
    return result


def initialize(connection):
    """Apply the versioned initial migration atomically on first use."""
    connection.execute('PRAGMA foreign_keys = ON')
    version = connection.execute('PRAGMA user_version').fetchone()[0]
    if version == 0:
        # A write lock prevents concurrent first-use migrations racing.
        connection.execute('BEGIN IMMEDIATE')
        try:
            version = connection.execute('PRAGMA user_version').fetchone()[0]
            if version == 0:
                for statement in SCHEMA.split(';'):
                    if statement.strip():
                        connection.execute(statement)
            elif version != 1:
                raise ValueError('unsupported database version')
            connection.commit()
        except Exception:
            connection.rollback()
            raise
    elif version != 1:
        raise ValueError('unsupported database version; use a version 1 file')


def require_task(connection, task_id):
    task = connection.execute(
        'SELECT * FROM tasks WHERE id = ?', (task_id,)).fetchone()
    if task is None:
        raise ValueError(f'task {task_id} does not exist')
    return task


def execute(connection, args):
    if args.command == 'add':
        # Validate that the initial recurrence fits the calendar range.
        args.due + timedelta(days=args.every)
        with connection:
            cursor = connection.execute(
                'INSERT INTO tasks(name, every_days, first_due) '
                'VALUES(?, ?, ?)',
                (args.name, args.every, args.due.isoformat()))
        print(f'Added task {cursor.lastrowid}: {args.name}')
    elif args.command == 'complete':
        if args.on > date.today():
            raise ValueError('completion date cannot be in the future')
        with connection:
            connection.execute('BEGIN IMMEDIATE')
            task = require_task(connection, args.id)
            args.on + timedelta(days=task['every_days'])
            connection.execute(
                'INSERT INTO completions(task_id, completed_on, recorded_at) '
                'VALUES(?, ?, ?)',
                (args.id, args.on.isoformat(),
                 datetime.now(timezone.utc).isoformat()))
        print(f'Completed task {args.id} on {args.on}')
    elif args.command == 'history':
        require_task(connection, args.id)
        rows = connection.execute(
            'SELECT completed_on, recorded_at FROM completions '
            'WHERE task_id = ? ORDER BY completed_on, id', (args.id,))
        records = [dict(row) for row in rows]
        print(json.dumps(records, indent=2))
    else:
        rows = connection.execute(
            'SELECT tasks.*, MAX(completed_on) AS last_completed '
            'FROM tasks LEFT JOIN completions ON tasks.id = task_id '
            'AND completed_on <= ? GROUP BY tasks.id ORDER BY tasks.id',
            (args.on.isoformat(),))
        records = []
        for row in rows:
            next_due = date.fromisoformat(row['first_due'])
            if row['last_completed']:
                next_due = (date.fromisoformat(row['last_completed'])
                            + timedelta(days=row['every_days']))
            due = next_due <= args.on
            if args.command == 'due' and not due:
                continue
            records.append({
                'id': row['id'], 'name': row['name'],
                'every_days': row['every_days'],
                'last_completed': row['last_completed'],
                'next_due': next_due.isoformat(), 'due': due,
            })
        print(json.dumps(records, indent=2))


def main(argv=None):
    args = parser().parse_args(argv)
    try:
        args.db.parent.mkdir(parents=True, exist_ok=True)
        with closing(sqlite3.connect(args.db, timeout=5)) as connection:
            connection.row_factory = sqlite3.Row
            initialize(connection)
            execute(connection, args)
        return 0
    except (ValueError, OverflowError) as error:
        print(f'Error: {error}', file=sys.stderr)
    except (OSError, sqlite3.Error):
        print('Error: cannot access task database; check path, permissions, '
              'file integrity, and whether another process holds a lock.',
              file=sys.stderr)
    return 1
