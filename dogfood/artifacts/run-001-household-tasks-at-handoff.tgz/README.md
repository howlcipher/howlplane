# Household tasks

A local CLI for recurring chores. Requires Python 3.10+ with SQLite support.
No service, network access, or runtime package installation is needed.
Run commands from this repository:

```bash
python3 -m household_tasks add "Wash sheets" --every 7
python3 -m household_tasks list
python3 -m household_tasks complete 1
python3 -m household_tasks due
python3 -m household_tasks history 1
python3 -m household_tasks --help
```

Tasks have stable numeric IDs; duplicate names are allowed. `list`, `due`, and
`history` print JSON, including completion dates and next due dates.

To set dates explicitly or use a separate database, put `--db` before the command:

```bash
python3 -m household_tasks --db data/demo.sqlite3 add "Clean filter" --every 30 --due 2024-01-01
python3 -m household_tasks --db data/demo.sqlite3 complete 1 --on 2024-01-02
python3 -m household_tasks --db data/demo.sqlite3 due --on 2024-02-01
python3 -m household_tasks --db data/demo.sqlite3 history 1
```

Dates must be `YYYY-MM-DD`. New tasks are due today unless `--due` sets their
first due date. Recurrence is a positive number of calendar days (maximum
365000). A task is due on or after its due date. Completion resets the next due
date to the completion date plus its interval, even if completed early or late.
Future completions are rejected. Every completion call records an event,
including repeats on the same day. History retains the completion date and
UTC recording timestamp. Backdated entries do not supersede later completions.
`list --on DATE` and `due --on DATE` evaluate the schedule using only completions
on or before that date; defaults use the computer's local calendar date.

Data persists in `data/tasks.sqlite3`, relative to the working directory.
Parent directories are created automatically. SQLite transactions protect
writes, with a five-second lock timeout. Keep a backup of this file while no
commands are running; restore by copying it back. Errors print to stderr and
exit nonzero; no automatic repair overwrites corrupt data.

Run the automated CLI tests and lint gate:

```bash
# flake8 is a development-only dependency; install if absent:
python3 -m pip install flake8
bash scripts/test.sh
```

The suite uses temporary databases inside this repository and launches separate
CLI processes to verify persistence. Design and Howl workflow evidence are in
[documentation/implementation.md](documentation/implementation.md).
