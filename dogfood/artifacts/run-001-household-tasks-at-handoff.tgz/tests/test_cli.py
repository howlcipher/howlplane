"""Exercise the real CLI in separate processes against isolated databases."""

from concurrent.futures import ThreadPoolExecutor
from datetime import date
import json
from pathlib import Path
import sqlite3
import subprocess
import sys
import tempfile
import unittest


ROOT = Path(__file__).resolve().parents[1]


class CliTests(unittest.TestCase):
    def setUp(self):
        self.directory = tempfile.TemporaryDirectory(dir=ROOT)
        self.addCleanup(self.directory.cleanup)
        self.db = Path(self.directory.name) / 'nested' / 'tasks.sqlite3'

    def run_cli(self, *args, success=True):
        result = subprocess.run(
            [sys.executable, '-m', 'household_tasks', '--db', str(self.db),
             *args], cwd=ROOT, capture_output=True, text=True, timeout=15)
        if success:
            self.assertEqual(result.returncode, 0, result.stderr)
        else:
            self.assertNotEqual(result.returncode, 0)
            self.assertNotIn('Traceback', result.stderr)
        return result

    def records(self, *args):
        return json.loads(self.run_cli(*args).stdout)

    def test_recurring_lifecycle_persists_across_processes(self):
        self.run_cli('add', 'Wash sheets', '--every', '7',
                     '--due', '2024-02-27')
        self.assertEqual(self.records('due', '--on', '2024-02-26'), [])
        self.assertTrue(self.records('due', '--on', '2024-02-27')[0]['due'])
        self.run_cli('complete', '1', '--on', '2024-02-28')
        task = self.records('list', '--on', '2024-03-05')[0]
        self.assertEqual(task['next_due'], '2024-03-06')
        self.assertEqual(task['last_completed'], '2024-02-28')
        self.assertFalse(task['due'])
        self.assertEqual(len(self.records('due', '--on', '2024-03-06')), 1)
        self.run_cli('complete', '1', '--on', '2024-03-06')
        history = self.records('history', '1')
        self.assertEqual([r['completed_on'] for r in history],
                         ['2024-02-28', '2024-03-06'])
        self.assertTrue(all('+00:00' in r['recorded_at'] for r in history))

    def test_backdated_completion_does_not_move_schedule_backwards(self):
        self.run_cli('add', 'Filter', '--every', '30', '--due', '2024-01-01')
        self.run_cli('complete', '1', '--on', '2024-02-01')
        self.run_cli('complete', '1', '--on', '2024-01-10')
        self.assertEqual(self.records('list', '--on', '2024-02-02')[0]
                         ['next_due'], '2024-03-02')
        self.assertEqual(self.records('list', '--on', '2024-01-11')[0]
                         ['next_due'], '2024-02-09')
        self.assertEqual(len(self.records('history', '1')), 2)

    def test_empty_and_default_dates(self):
        self.assertEqual(self.records('list'), [])
        self.run_cli('add', 'Sweep', '--every', '1')
        self.assertEqual(self.records('due')[0]['next_due'],
                         date.today().isoformat())
        self.run_cli('complete', '1')
        self.assertEqual(self.records('due'), [])

    def test_invalid_arguments_do_not_create_database(self):
        cases = [
            ('add', '', '--every', '7'),
            ('add', 'x', '--every', '0'),
            ('add', 'x', '--every', '-1'),
            ('add', 'x', '--every', 'abc'),
            ('add', 'x', '--every', '1', '--due', '2024-02-30'),
            ('add', 'x', '--every', '1', '--due', '20240201'),
            ('add', 'x\nInjected', '--every', '1'),
            ('complete', '-1'),
        ]
        for args in cases:
            with self.subTest(args=args):
                self.run_cli(*args, success=False)
                self.assertFalse(self.db.exists())

    def test_failed_completion_preserves_history(self):
        self.run_cli('add', 'Sweep', '--every', '1')
        for args in [('complete', '999'), ('history', '999'),
                     ('complete', '1', '--on', '9999-12-31')]:
            self.run_cli(*args, success=False)
        self.assertEqual(self.records('history', '1'), [])

    def test_corrupt_database_and_invalid_path_are_reported(self):
        self.db.parent.mkdir()
        self.db.write_text('invalid database')
        self.run_cli('list', success=False)
        self.assertEqual(self.db.read_text(), 'invalid database')
        self.db = self.db / 'impossible.sqlite3'
        self.run_cli('list', success=False)

    def test_future_schema_rejected(self):
        self.run_cli('list')
        with sqlite3.connect(self.db) as connection:
            connection.execute('PRAGMA user_version = 99')
        self.run_cli('add', 'x', '--every', '1', success=False)

    def test_names_are_sql_data_and_ids_are_stable(self):
        name = "Clean '); DROP TABLE tasks; -- 🧹"
        self.run_cli('add', name, '--every', '1')
        self.run_cli('add', name, '--every', '2')
        rows = self.records('list')
        self.assertEqual([r['id'] for r in rows], [1, 2])
        self.assertEqual([r['name'] for r in rows], [name, name])

    def test_concurrent_first_use_and_additions(self):
        with ThreadPoolExecutor(max_workers=4) as pool:
            futures = [pool.submit(self.run_cli, 'add', f'Task {i}',
                                   '--every', '7') for i in range(8)]
            for future in futures:
                future.result()
        rows = self.records('list')
        self.assertEqual(len(rows), 8)
        self.assertEqual(len({r['id'] for r in rows}), 8)

    def test_calendar_overflow_rejected(self):
        self.run_cli('add', 'x', '--every', '7', '--due', '9999-12-31',
                     success=False)
        self.assertEqual(self.records('list'), [])

    def test_help(self):
        result = self.run_cli('--help')
        self.assertIn('complete', result.stdout)
        self.assertFalse(self.db.exists())


if __name__ == '__main__':
    unittest.main()
