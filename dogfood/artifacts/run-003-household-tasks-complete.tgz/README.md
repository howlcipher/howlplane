# Household tasks

A small local CLI for recurring chores. Requires Python 3.10 or newer with
SQLite support. No installation or runtime dependencies are needed.

From this directory:

```bash
python3 household_tasks.py add "Clean kitchen filter" --every 7
python3 household_tasks.py list
python3 household_tasks.py due
python3 household_tasks.py complete 1
python3 household_tasks.py history 1
python3 household_tasks.py --help
```

Tasks have stable numeric IDs. `--every` is a fixed interval of 1 to 36500 days.
New tasks are due today, or on the `add --start YYYY-MM-DD` date you choose.
Completion records the local calendar date and resets the next due date to the
completion date plus the interval. Each completion remains in `history`.
A task is due when its next due date is on or before the selected date.

Use `due --on YYYY-MM-DD` to inspect another date, or
`complete ID --on YYYY-MM-DD` to record a past completion. Future completions,
repeated completions on the same date, and dates before the previous completion
are rejected. Early completion is allowed. Recurrence uses days, not months,
and dates have no time of day or timezone conversion.

Data lives in `~/.household_tasks/tasks.sqlite3` by default. To keep data in a
chosen location, place the global `--db` option before the command:

```bash
python3 household_tasks.py --db ./data/tasks.sqlite3 add "Water plants" --every 3
python3 household_tasks.py --db ./data/tasks.sqlite3 list
```

Parent directories are created automatically. Writes are transactional, and
SQLite serializes simultaneous updates with a five-second lock timeout.
Errors go to stderr with exit status 2; success returns 0. Back up the database
while no command is running. Storage permissions follow your operating system
and umask. This application provides no encryption, deletion, editing, or
calendar-based recurrence.

Run the automated CLI integration suite:

```bash
python3 -m unittest discover -s tests -v
```

Optional development lint requires flake8:

```bash
python3 -m flake8 --jobs 1 household_tasks.py tests
```

Design, workflow decisions, and verification scope are recorded in
[the implementation journal](documentation/implementation_journal.md).
