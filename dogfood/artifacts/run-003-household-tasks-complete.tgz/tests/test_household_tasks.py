import os
from pathlib import Path
import sqlite3
import subprocess
import sys
import tempfile
import unittest


CLI = Path(__file__).resolve().parents[1] / 'household_tasks.py'


class HouseholdTasksTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.db = Path(self.temp.name) / 'tasks.sqlite3'

    def run_cli(self, *args, success=True):
        result = subprocess.run(
            [sys.executable, str(CLI), '--db', str(self.db), *args],
            text=True, capture_output=True, timeout=10,
        )
        self.assertEqual(result.returncode, 0 if success else 2,
                         result.stderr)
        self.assertNotIn('Traceback', result.stderr)
        if not success:
            self.assertIn('error:', result.stderr.lower())
        return result.stdout if success else result.stderr

    def test_lifecycle_persistence_due_boundary_and_history(self):
        self.run_cli('add', 'Clean filter', '--every', '7',
                     '--start', '2024-02-22')
        self.assertIn('Clean filter', self.run_cli('list'))
        self.assertIn('Clean filter', self.run_cli(
            'due', '--on', '2024-02-22'))
        self.run_cli('complete', '1', '--on', '2024-02-22')
        self.assertNotIn('Clean filter', self.run_cli(
            'due', '--on', '2024-02-28'))
        self.assertIn('Clean filter', self.run_cli(
            'due', '--on', '2024-02-29'))
        self.run_cli('complete', '1', '--on', '2024-03-01')
        listing = self.run_cli('list')
        self.assertIn('2024-03-08', listing)
        self.assertIn('2024-03-01', listing)
        history = self.run_cli('history', '1')
        self.assertIn('2024-02-22', history)
        self.assertIn('2024-03-01', history)
        with sqlite3.connect(self.db) as connection:
            self.assertEqual(connection.execute(
                'SELECT count(*) FROM completions').fetchone()[0], 2)

    def test_invalid_inputs_do_not_mutate_data(self):
        for args in [('add', ' ', '--every', '7'),
                     ('add', 'Bad\nname', '--every', '7'),
                     ('add', 'Bad', '--every', '0'),
                     ('add', 'Bad', '--every', '-1'),
                     ('add', 'Bad', '--every', 'abc'),
                     ('add', 'Bad', '--every', '36501'),
                     ('add', 'Bad', '--every', '7', '--start', '20240222'),
                     ('add', 'Bad', '--every', '7', '--start', '2024-02-30')]:
            self.run_cli(*args, success=False)
        self.run_cli('add', "Wash ' windows", '--every', '1',
                     '--start', '2024-01-01')
        self.assertIn('does not exist', self.run_cli(
            'complete', '40000', success=False))
        self.run_cli('complete', str(2 ** 63), success=False)
        self.run_cli('complete', '1', '--on', '9999-01-01', success=False)
        self.assertIn('No completions', self.run_cli('history', '1'))
        self.run_cli('complete', '1', '--on', '2024-01-02')
        self.run_cli('complete', '1', '--on', '2024-01-01', success=False)
        self.run_cli('complete', '1', '--on', '2024-01-02', success=False)
        self.assertEqual(self.run_cli('history', '1').count('2024-01-02'), 1)

    def test_empty_and_unknown_history(self):
        self.assertIn('No tasks', self.run_cli('list'))
        self.assertIn('No tasks', self.run_cli('due'))
        self.run_cli('history', '999', success=False)

    def test_corrupt_database_preserved(self):
        self.db.write_bytes(b'not a sqlite database')
        self.run_cli('list', success=False)
        self.assertEqual(self.db.read_bytes(), b'not a sqlite database')

    def test_default_storage_is_local_to_home(self):
        env = dict(os.environ, HOME=self.temp.name)
        result = subprocess.run(
            [sys.executable, str(CLI), 'list'], env=env,
            text=True, capture_output=True, timeout=10,
        )
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertTrue((Path(self.temp.name) / '.household_tasks' /
                         'tasks.sqlite3').is_file())


if __name__ == '__main__':
    unittest.main()
