"""Local recurring household tasks, using only the Python standard library."""

import argparse
from datetime import date, timedelta
from pathlib import Path
import sqlite3
import sys


SCHEMA = """
CREATE TABLE IF NOT EXISTS tasks (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    interval_days INTEGER NOT NULL CHECK(interval_days > 0),
    next_due TEXT NOT NULL,
    last_completed TEXT
);
CREATE TABLE IF NOT EXISTS completions (
    id INTEGER PRIMARY KEY,
    task_id INTEGER NOT NULL REFERENCES tasks(id),
    completed_on TEXT NOT NULL,
    UNIQUE(task_id, completed_on)
);
"""


def calendar_date(value):
    try:
        parsed = date.fromisoformat(value)
        if parsed.isoformat() != value:
            raise ValueError()
        return parsed
    except ValueError:
        raise argparse.ArgumentTypeError('use a valid YYYY-MM-DD date')


def positive_integer(value):
    try:
        number = int(value)
        if not 1 <= number <= 36500:
            raise ValueError()
        return number
    except ValueError:
        raise argparse.ArgumentTypeError('use an integer from 1 to 36500')


def task_id(value):
    try:
        number = int(value)
        if not 1 <= number <= 9223372036854775807:
            raise ValueError()
        return number
    except ValueError:
        raise argparse.ArgumentTypeError('use a positive SQLite task ID')


def task_name(value):
    name = value.strip()
    if not name or len(name) > 200 or any(
            not char.isprintable() for char in name):
        raise argparse.ArgumentTypeError(
            'task name must contain 1 to 200 printable characters')
    return name


def parser():
    result = argparse.ArgumentParser(description=__doc__)
    result.add_argument('--db', type=Path,
                        default=Path.home() / '.household_tasks' /
                        'tasks.sqlite3', help='local SQLite database path')
    commands = result.add_subparsers(dest='command', required=True)
    add = commands.add_parser('add', help='add a recurring task')
    add.add_argument('name', type=task_name)
    add.add_argument('--every', type=positive_integer, required=True,
                     help='repeat interval in days')
    add.add_argument('--start', type=calendar_date, default=date.today(),
                     help='first due date (default: today)')
    commands.add_parser('list', help='list all tasks')
    due = commands.add_parser('due', help='list tasks due on or before a date')
    due.add_argument('--on', type=calendar_date, default=date.today())
    complete = commands.add_parser('complete', help='record a completion')
    complete.add_argument('id', type=task_id)
    complete.add_argument('--on', type=calendar_date, default=date.today())
    history = commands.add_parser('history', help='show completion dates')
    history.add_argument('id', type=task_id)
    return result


def show_tasks(rows):
    if not rows:
        print('No tasks.')
        return
    print('ID\tTask\tEvery (days)\tNext due\tLast completed')
    for row in rows:
        print('\t'.join(str(value) if value is not None else 'never'
                        for value in row))


def execute(connection, args):
    if args.command == 'add':
        cursor = connection.execute(
            'INSERT INTO tasks(name, interval_days, next_due) VALUES(?, ?, ?)',
            (args.name, args.every, args.start.isoformat()),
        )
        return f'Added task {cursor.lastrowid}: {args.name}'
    if args.command in ('list', 'due'):
        query = ('SELECT id, name, interval_days, next_due, last_completed '
                 'FROM tasks')
        parameters = ()
        if args.command == 'due':
            query += ' WHERE next_due <= ?'
            parameters = (args.on.isoformat(),)
        show_tasks(connection.execute(
            query + ' ORDER BY next_due, id', parameters).fetchall())
        return None
    task = connection.execute(
        'SELECT name, interval_days, last_completed FROM tasks WHERE id = ?',
        (args.id,),
    ).fetchone()
    if task is None:
        raise ValueError(f'task {args.id} does not exist')
    if args.command == 'history':
        dates = connection.execute(
            'SELECT completed_on FROM completions WHERE task_id = ? '
            'ORDER BY completed_on, id', (args.id,),
        ).fetchall()
        print(f'Completion history for {args.id}: {task[0]}')
        for completed in dates:
            print(completed[0])
        if not dates:
            print('No completions.')
        return None
    if args.on > date.today():
        raise ValueError('completion date cannot be in the future')
    if task[2] is not None and args.on.isoformat() <= task[2]:
        raise ValueError('completion must be later than the last completion')
    next_due = (args.on + timedelta(days=task[1])).isoformat()
    connection.execute(
        'INSERT INTO completions(task_id, completed_on) VALUES(?, ?)',
        (args.id, args.on.isoformat()),
    )
    connection.execute(
        'UPDATE tasks SET last_completed = ?, next_due = ? WHERE id = ?',
        (args.on.isoformat(), next_due, args.id),
    )
    return f'Completed task {args.id}; next due {next_due}'


def main(argv=None):
    args = parser().parse_args(argv)
    connection = None
    try:
        args.db.parent.mkdir(parents=True, exist_ok=True)
        connection = sqlite3.connect(args.db, timeout=5)
        connection.execute('PRAGMA foreign_keys = ON')
        connection.executescript(SCHEMA)
        # Serialize the read and update so concurrent completions cannot race.
        connection.execute('BEGIN IMMEDIATE')
        with connection:
            message = execute(connection, args)
        if message:
            print(message)
        return 0
    except (OSError, sqlite3.Error, ValueError, OverflowError) as error:
        print(f'Error: {error}', file=sys.stderr)
        return 2
    finally:
        if connection is not None:
            connection.close()


if __name__ == '__main__':
    sys.exit(main())
