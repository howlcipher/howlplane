# Implementation journal

## Discovery and Howl routing

The initial working tree was clean. The only tracked project file was a
placeholder README; there were no partial implementation changes, stack markers,
local testing policy, or project control-plane tools. `.agents/skills` was absent;
the installed skills resolve to the canonical HowlPlane library.

Applied the canonical `route_task` prompt, grounding, software development,
architectural guardrails, Python, quality assurance, and test and verify skills.
Read the canonical rules directory. The user authorizes implementation within
this repository and prohibits commit, publish, push, or other worktree changes.

Executed the normal deterministic route in the target repository:

```bash
howlplane route 'Build a recurring household task command line application with local persistence' --repo . --role implementation --risk low --json --semantic off
```

Result: `SELECTED`, task class `feature`, role `implementation`, recommended
resource `agy`, strategy `deterministic_router/v1`. Continued using the assigned
Codex implementation role rather than launching another implementation process.
Reasoning classification: tier 2 standard feature, low risk, local storage only.
Suggested review lenses: correctness, test falsification, regression, simplicity.
These lenses were used for self-review; no independent agent review was performed.

The first route with the full requirements hit a live control-plane validation
error: task class `test` is invalid. The shorter objective succeeded. This is a
library update candidate: the documented router is operational, but live routing
can fail on objectives containing testing requirements. No control-plane files
were changed.

## Approach selection

| Approach | Advantages | Costs |
| --- | --- | --- |
| Python standard library | Available locally; argparse, dates, SQLite and testing included | Requires Python on the user's machine |
| Go | Standalone binary; static typing | SQLite needs additional integration or another persistence design |
| Bash | Easy invocation on Unix | Date portability, structured history and transactional storage are harder |
| HowlFrame | Native bounded-runtime ecosystem | New language/toolchain adds deployment and integration requirements to this small standalone CLI |

Selected Python after discovery and routing because it satisfies every contract
without downloads or runtime dependencies. SQLite offers transactions, stable
IDs, history and update serialization. JSON is easier to inspect manually but
needs replacement and locking logic to protect concurrent writers. No server,
background worker, remote integration or infrastructure is needed.

## Observable contract and test impact

Commands: add, list, due, complete, history. Tasks begin due today or on an explicit
start date. Completing a task advances its next due date from the completion date.
Completion dates must be today or earlier and strictly increase for each task.
All historical dates remain queryable. Due comparison is inclusive.

Added subprocess integration tests before implementation; four failed because
the application did not yet exist. Every invocation runs independently against
a temporary database. Tests cover persistence, due boundaries across leap day,
repeated history, input rejection, no mutation on invalid completion, missing IDs,
empty storage, corrupt database preservation and the default home-relative path.
There was no existing regression suite to retain or remove. The full applicable
gate is unittest discovery plus flake8 for all application and test code.
No project-local `tia` or testing policy exists, so this file records the impact
assessment rather than modifying shared control-plane evidence outside scope.

## Remaining limitations

Fixed day intervals only; one completion per calendar day; no editing or deletion.
SQLite errors are reported without tracebacks; incompatible or damaged databases
require user recovery. No schema migration or encrypted storage is provided.
Concurrent writes are serialized by SQLite, but stress testing and crash/power-loss
fault injection are outside this small application's verification scope.

## Final verification

`python3 -m unittest discover -s tests -v`: five tests passed, exercising many
independent CLI processes. `python3 -m flake8 --jobs 1 household_tasks.py tests`:
passed. The initial default flake8 process pool was blocked by sandbox socket
permissions; single-worker execution completed normally. `git diff --check`:
passed. CLI `--help` and a temporary-database add/list/due/complete/history/due
sequence passed; completion on 2026-10-03 advanced the next due date to 2026-10-10
and removed the task from the current due list. The demo database was removed
by its temporary-directory context.

Self-review checked parameterized SQL, control-character rejection, date
validation, stable signed 64-bit SQLite IDs, duplicate completion rejection,
transaction rollback, bounded database lock waits and history ordering. No
external services, runtime downloads or other worktree modifications were used.
Completion status: complete for the requested CLI scope. No commit, push,
publishing or deployment was performed.
