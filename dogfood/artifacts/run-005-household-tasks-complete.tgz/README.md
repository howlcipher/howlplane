# Household tasks

A local CLI for recurring chores. Requires Python 3.10+; the application uses
only the standard library. Run from this directory:

```bash
python3 household.py add "Wash sheets" --every 7
python3 household.py list
python3 household.py due
python3 household.py complete 1
python3 household.py history 1
```

Tasks are due immediately by default. `add --due YYYY-MM-DD` sets the first due
date; `complete --on YYYY-MM-DD` records a historical completion (default: the
local calendar date today). `list --on` and `due --on` evaluate another date.
Due means the next due date is on or before the evaluation date. After completion,
the next due date is the completion date plus the interval in calendar days;
missed occurrences do not accumulate. Completion history is retained. Dates must
be YYYY-MM-DD; intervals must be 1–36500 days. Future completions and completions
on or before the most recent completion are rejected. Early completion is allowed.

Data persists in `~/.local/share/household-tasks/tasks.sqlite3`. Place `--db PATH`
before the command to use another database. SQLite transactions keep completion
history and scheduling updates atomic, including across concurrent invocations.
Back up the database when no command is running. No network services are used.
Errors return a nonzero exit status and a message on stderr.

A reproducible demonstration with an isolated database:

```bash
python3 household.py --db data/demo.sqlite3 add "Wash sheets" --every 7 --due 2024-02-20
python3 household.py --db data/demo.sqlite3 complete 1 --on 2024-02-24
python3 household.py --db data/demo.sqlite3 due --on 2024-03-01
python3 household.py --db data/demo.sqlite3 due --on 2024-03-02
python3 household.py --db data/demo.sqlite3 history 1
```

Run automated CLI tests and lint (development dependency: flake8):

```bash
bash scripts/test.sh
```

See [design and workflow notes](documentation/design.md) for the implementation
choice and limits.
