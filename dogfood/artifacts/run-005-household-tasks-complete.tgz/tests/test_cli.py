"""Exercise real CLI processes against isolated on-disk databases."""

from datetime import date, timedelta
from pathlib import Path
import sqlite3
import subprocess
import sys
import tempfile
import unittest


APP = Path(__file__).resolve().parents[1] / "household.py"


class HouseholdTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.db = Path(self.temp.name) / "nested/tasks.sqlite3"

    def run_cli(self, *args, success=True):
        result = subprocess.run(
            [sys.executable, str(APP), "--db", str(self.db), *args],
            capture_output=True, text=True, timeout=10,
        )
        if success:
            self.assertEqual(result.returncode, 0, result.stderr)
        else:
            self.assertNotEqual(result.returncode, 0)
            self.assertNotIn("Traceback", result.stderr)
        return result

    def test_persistent_recurrence_and_history(self):
        self.run_cli("add", "Wash sheets", "--every", "7",
                     "--due", "2024-02-20")
        self.assertIn("DUE", self.run_cli("due", "--on", "2024-02-20").stdout)
        result = self.run_cli("complete", "1", "--on", "2024-02-24")
        self.assertIn("next due 2024-03-02", result.stdout)
        listing = self.run_cli("list", "--on", "2024-03-01").stdout
        self.assertIn("2024-02-24", listing)
        self.assertIn("upcoming", listing)
        self.assertEqual(self.run_cli("due", "--on", "2024-03-01").stdout,
                         "No tasks found.\n")
        self.assertIn("Wash sheets",
                      self.run_cli("due", "--on", "2024-03-02").stdout)
        self.run_cli("complete", "1", "--on", "2024-03-03")
        self.assertEqual(self.run_cli("history", "1").stdout,
                         "2024-02-24\n2024-03-03\n")

    def test_empty_and_defaults(self):
        self.assertEqual(self.run_cli("list").stdout, "No tasks found.\n")
        self.run_cli("add", "Vacuum", "--every", "1")
        self.assertIn(date.today().isoformat(), self.run_cli("due").stdout)
        self.assertEqual(self.run_cli("history", "1").stdout,
                         "No completions recorded.\n")
        self.run_cli("complete", "1")
        self.assertIn((date.today() + timedelta(days=1)).isoformat(),
                      self.run_cli("list").stdout)

    def test_invalid_inputs_do_not_create_database(self):
        for args in [
            ("add", " ", "--every", "7"),
            ("add", "bad\nname", "--every", "7"),
            ("add", "Clean", "--every", "0"),
            ("add", "Clean", "--every", "-2"),
            ("add", "Clean", "--every", "1.5"),
            ("add", "Clean", "--every", "36501"),
            ("add", "Clean", "--every", "7", "--due", "2024-02-30"),
            ("due", "--on", "20240220"),
            ("complete", "0"),
        ]:
            with self.subTest(args=args):
                self.run_cli(*args, success=False)
                self.assertFalse(self.db.exists())

    def test_completion_errors_preserve_state(self):
        self.run_cli("add", "Clean", "--every", "7")
        self.run_cli("complete", "1", "--on", "2024-01-10")
        before = self.run_cli("list").stdout
        for args in [
            ("complete", "999"),
            ("history", "999"),
            ("complete", "1", "--on", "2024-01-09"),
            ("complete", "1", "--on", "2024-01-10"),
            ("complete", "1", "--on", "9999-12-31"),
        ]:
            with self.subTest(args=args):
                self.run_cli(*args, success=False)
                self.assertEqual(self.run_cli("list").stdout, before)
        self.assertEqual(self.run_cli("history", "1").stdout, "2024-01-10\n")

    def test_date_overflow_rejected(self):
        self.run_cli("add", "Clean", "--every", "7",
                     "--due", "9999-12-31", success=False)
        self.assertEqual(self.run_cli("list").stdout, "No tasks found.\n")

    def test_literal_names_and_due_filter(self):
        self.run_cli("add", "Bob's mop; DROP TABLE tasks;", "--every", "7",
                     "--due", "2024-01-01")
        self.run_cli("add", "Later", "--every", "30",
                     "--due", "2024-02-01")
        listing = self.run_cli("due", "--on", "2024-01-01").stdout
        self.assertIn("Bob's mop; DROP TABLE tasks;", listing)
        self.assertNotIn("Later", listing)

    def test_storage_errors(self):
        self.db.parent.mkdir()
        self.db.write_text("not a database")
        self.run_cli("list", success=False)
        self.assertEqual(self.db.read_text(), "not a database")
        self.db.unlink()
        self.db.mkdir()
        self.run_cli("list", success=False)

    def test_transaction_rollback(self):
        self.run_cli("add", "Clean", "--every", "7")
        with sqlite3.connect(self.db) as connection:
            connection.execute(
                "CREATE TRIGGER reject_update BEFORE UPDATE ON tasks "
                "BEGIN SELECT RAISE(ABORT, 'test failure'); END"
            )
        self.run_cli("complete", "1", "--on", "2024-01-10", success=False)
        self.assertEqual(self.run_cli("history", "1").stdout,
                         "No completions recorded.\n")


if __name__ == "__main__":
    unittest.main()
