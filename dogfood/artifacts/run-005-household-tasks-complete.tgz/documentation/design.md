# Design and workflow

Inspected the initially clean repository: only a placeholder README existed.
Local `.agents/skills` and `.agents/rules` were absent. Applied the installed
software_development, python, hallucination_guardrails, and test_and_verify
skills. Their referenced route-task prompt and anti-manipulation rule were not
available locally; no external content was executed as instructions.

Used installed HowlPlane routing before implementation. The initial long goal
failed with an invalid `test` task class (diagnostic HP-20261003-010103-8847).
A focused feature objective with `--semantic off` routed successfully as a
feature/implementation task. Routing recommended agy; this run retains the
user-assigned Codex implementation role without launching another workflow or
changing other worktrees. No HowlFrame language requirement was imposed.

| Approach | Advantages | Costs |
| --- | --- | --- |
| Python + SQLite | Standard-library CLI, dates, transactional persistence, easy isolated tests | Requires Python; no standalone binary |
| Go | Standalone executable, static types | More date/CLI plumbing; SQLite needs a dependency or custom file storage |
| HowlFrame | Capability-bounded VM and structured store | Compiler/runtime dependency; installed flags differ from skill examples; date support needs validation |

Selected Python + SQLite for the small local CLI. Integer task IDs identify
chores; duplicate names are allowed. Tasks store the next due date, while a
separate completion table retains history. SQL parameters preserve literal task
names. An immediate transaction serializes reads and writes, and rolls back both
history and scheduling on failure. Calendar-day intervals avoid timezone and
wall-clock ambiguities. Local dates intentionally have no time of day.

Verification uses subprocesses and temporary databases to test persistence,
leap-day recurrence, due boundaries, history, defaults, invalid input, missing
IDs, future/backdated completions, corrupt storage, and transaction rollback.
The final gate is `bash scripts/test.sh` (unittest and flake8).

Limits: no editing/deletion, notifications, calendar-month intervals, import,
or schema migration mechanism. This is a local single-user database; filesystem
permissions provide access control. Manual database modification is unsupported.
