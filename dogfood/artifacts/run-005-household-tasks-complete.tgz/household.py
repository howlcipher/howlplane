#!/usr/bin/env python3
"""Local recurring household tasks, stored transactionally in SQLite."""

import argparse
from datetime import date, timedelta
from pathlib import Path
import sqlite3
import sys


SCHEMA = """
CREATE TABLE IF NOT EXISTS tasks (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL,
    interval_days INTEGER NOT NULL CHECK(interval_days > 0),
    next_due TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS completions (
    id INTEGER PRIMARY KEY,
    task_id INTEGER NOT NULL REFERENCES tasks(id),
    completed_on TEXT NOT NULL
);
"""


def parse_date(value):
    try:
        parsed = date.fromisoformat(value)
        if parsed.isoformat() != value:
            raise ValueError
        return parsed
    except ValueError:
        raise argparse.ArgumentTypeError("use a date in YYYY-MM-DD format")


def positive_int(value):
    try:
        number = int(value)
        if not 1 <= number <= 36500:
            raise ValueError
        return number
    except ValueError:
        raise argparse.ArgumentTypeError("use an integer from 1 to 36500")


def task_id(value):
    try:
        number = int(value)
        if number < 1:
            raise ValueError
        return number
    except ValueError:
        raise argparse.ArgumentTypeError("task ID must be a positive integer")


def nonempty_name(value):
    value = value.strip()
    if not value or any(ord(char) < 32 or ord(char) == 127 for char in value):
        raise argparse.ArgumentTypeError(
            "name must be nonempty printable text"
        )
    return value


def parser():
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument(
        "--db", type=Path,
        default=Path.home() / ".local/share/household-tasks/tasks.sqlite3",
        help="database path (default: "
             "~/.local/share/household-tasks/tasks.sqlite3)",
    )
    commands = cli.add_subparsers(dest="command", required=True)
    add = commands.add_parser("add", help="add a task with a day interval")
    add.add_argument("name", type=nonempty_name)
    add.add_argument(
        "--every", type=positive_int, required=True, metavar="DAYS"
    )
    add.add_argument("--due", type=parse_date, default=date.today())
    for command in ("list", "due"):
        listing = commands.add_parser(command, help="show tasks and due dates")
        listing.add_argument("--on", type=parse_date, default=date.today())
    complete = commands.add_parser("complete", help="record a completion")
    complete.add_argument("id", type=task_id)
    complete.add_argument("--on", type=parse_date, default=date.today())
    history = commands.add_parser("history", help="show recorded completions")
    history.add_argument("id", type=task_id)
    return cli


def execute(db, args):
    if args.command == "add":
        # Ensure a recurrence can be represented before accepting the task.
        args.due + timedelta(days=args.every)
        cursor = db.execute(
            "INSERT INTO tasks(name, interval_days, next_due) "
            "VALUES (?, ?, ?)",
            (args.name, args.every, args.due.isoformat()),
        )
        return f"Added task {cursor.lastrowid}: {args.name}"
    if args.command in ("list", "due"):
        rows = db.execute(
            "SELECT t.*, (SELECT MAX(completed_on) FROM completions "
            "WHERE task_id = t.id) AS last_completed "
            "FROM tasks t ORDER BY next_due, id"
        ).fetchall()
        lines = ["ID\tTASK\tEVERY DAYS\tLAST COMPLETED\tNEXT DUE\tSTATUS"]
        for row in rows:
            due = row["next_due"] <= args.on.isoformat()
            if args.command == "due" and not due:
                continue
            lines.append(
                f"{row['id']}\t{row['name']}\t{row['interval_days']}\t"
                f"{row['last_completed'] or '-'}\t{row['next_due']}\t"
                f"{'DUE' if due else 'upcoming'}"
            )
        return "\n".join(lines) if len(lines) > 1 else "No tasks found."
    task = db.execute(
        "SELECT * FROM tasks WHERE id = ?", (args.id,)
    ).fetchone()
    if task is None:
        raise ValueError(f"task {args.id} does not exist")
    if args.command == "history":
        rows = db.execute(
            "SELECT completed_on FROM completions WHERE task_id = ? "
            "ORDER BY completed_on, id", (args.id,)
        ).fetchall()
        return "\n".join(row[0] for row in rows) or "No completions recorded."
    if args.on > date.today():
        raise ValueError("completion date cannot be in the future")
    last = db.execute(
        "SELECT MAX(completed_on) FROM completions WHERE task_id = ?",
        (args.id,),
    ).fetchone()[0]
    if last and args.on.isoformat() <= last:
        raise ValueError(
            "completion date must be later than the last completion"
        )
    next_due = args.on + timedelta(days=task["interval_days"])
    db.execute(
        "INSERT INTO completions(task_id, completed_on) VALUES (?, ?)",
        (args.id, args.on.isoformat()),
    )
    db.execute(
        "UPDATE tasks SET next_due = ? WHERE id = ?",
        (next_due.isoformat(), args.id),
    )
    return f"Completed task {args.id} on {args.on}; next due {next_due}"


def main(argv=None):
    args = parser().parse_args(argv)
    db = None
    try:
        args.db.parent.mkdir(parents=True, exist_ok=True)
        db = sqlite3.connect(args.db, timeout=5)
        db.row_factory = sqlite3.Row
        db.execute("PRAGMA foreign_keys = ON")
        db.executescript(SCHEMA)
        # Lock before reading so parallel completions cannot race.
        db.execute("BEGIN IMMEDIATE")
        output = execute(db, args)
        db.commit()
        print(output)
        return 0
    except (OSError, sqlite3.Error, ValueError, OverflowError) as error:
        if db is not None:
            db.rollback()
        print(f"Error: {error}", file=sys.stderr)
        return 1
    finally:
        if db is not None:
            db.close()


if __name__ == "__main__":
    sys.exit(main())
