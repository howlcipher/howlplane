# Incident Sift

Python 3.11+ standard-library CLI for deterministic incident summaries. No runtime
or build dependencies and no network access are needed. Run from this checkout:

```bash
python3 -m incident_sift --help
python3 -m incident_sift --version
printf '%s\n' '{"timestamp":"2026-10-28T12:15:00+02:00","source":"web","category":"failure","level":"error","message":"private"}' > events.jsonl
python3 -m incident_sift events.jsonl
python3 -m incident_sift --source web --category failure --minimum-level error --since 2026-10-28T10:00:00Z --until 2026-10-28T11:00:00Z events.jsonl
python3 -m incident_sift --strict < events.jsonl
```

The sample produces one accepted record and a group with category `failure`,
source `web`, UTC hour `2026-10-28T10:00:00Z`, and count 1.
With no paths, input is stdin; `-` explicitly selects stdin and may occur once.
Multiple paths are processed in argument order. Input files must be UTF-8 JSONL,
one JSON object per line. Blank lines are rejected; a final newline is optional.

Each record requires exactly these field types (additional fields are allowed):

| Field | Requirement |
| --- | --- |
| timestamp | String accepted by Python's `datetime.fromisoformat`, with timezone; must normalize to a representable UTC datetime |
| source, category | Nonempty strings after checking whitespace; original whitespace is otherwise preserved |
| level | String: `debug`, `info`, `warning`, `error`, or `critical` |
| message | String, including empty string |

Malformed JSON, invalid UTF-8, missing fields, wrong types, invalid timestamps,
non-object records, and nonstandard `NaN`, `Infinity`, or `-Infinity` constants
(including nested metadata) count as rejected. Validation happens before filters;
processing continues after rejected lines. Additional fields are ignored after
JSON decoding. Duplicate JSON keys use Python's last-key-wins behavior.

Output is one compact JSON object plus newline. `counts` contains `accepted`
(valid records passing filters), `filtered` (valid records failing any filter),
and `rejected` (invalid lines). Accepted debug/info/warning records contribute to
counts but not groups. Error/critical records are grouped by category, UTC hour,
and source. Groups sort by those three fields; JSON object keys also sort.
Equivalent input records give identical bytes, regardless of input order.

`--source` and `--category` match original strings exactly, before redaction.
`--minimum-level` defaults to debug and follows the level order shown above.
`--since` is inclusive and `--until` exclusive, using aware timestamps normalized
to UTC. Equal boundaries accept no records; reversed boundaries are usage errors.

Reports omit messages and metadata. Group labels matching email, bearer, token,
password/passwd, API-key (including `api.key`), or common credential-prefix
patterns are replaced in full with `[REDACTED]`. Matching is case-insensitive;
redacted labels merge into the same group. This is pattern-based protection:
unknown secret formats may remain visible and benign matching labels may be
redacted. Diagnostics omit raw records, option values, and paths entirely.

Exit codes: 0 for a completed report (even with rejections normally); 1 for a
completed `--strict` report with rejections; 2 for invalid arguments or input/output
errors. Input errors such as an unreadable file produce a generic diagnostic and
no report; earlier records are discarded. Help and version exit 0.

## Test and build

From the checkout root, on a POSIX system with Bash and Python 3.11+ including
`venv` and pip bootstrapping support:

```bash
bash scripts/test.sh
bash scripts/build.sh
```

Tests use unittest discovery, exercise CLI behavior, build twice and compare
hashes, then extract and install into a fresh temporary venv offline and run the
installed command outside the source directory. Build writes
`dist/incident_sift-1.0.0.tar.gz`. Its explicit file allowlist includes package
Python files, tests, shell scripts, README, pyproject, and the build backend;
it excludes logs, local data, VCS files, caches, and prior artifacts. Sorted
entries, fixed timestamps, normalized ownership/permissions, and a fixed gzip
header make repeated builds of unchanged source byte-identical with the same
Python toolchain. The small in-tree PEP 517 backend also writes wheels without
third-party build tools.

## Clean offline installation

After the build above, run from the checkout root. Use a new directory name if
`install-check` already exists. No activation is needed:

```bash
mkdir install-check
tar -xzf dist/incident_sift-1.0.0.tar.gz -C install-check
python3 -m venv install-check/venv
install-check/venv/bin/python -m pip install --no-index --no-deps --no-build-isolation --no-cache-dir --disable-pip-version-check ./install-check/incident_sift-1.0.0
cd install-check
venv/bin/incident-sift --version
venv/bin/incident-sift --help
printf '%s\n' '{"timestamp":"2026-10-28T10:15:00Z","source":"web","category":"failure","level":"error","message":"private"}' | venv/bin/incident-sift --strict
cd ..
```

The console script is declared in `pyproject.toml` as
`incident-sift = incident_sift.cli:main`. The installation uses only the extracted
source and the fresh environment; no globally installed packaging backend is
required. Remove `install-check` when finished.
