"""Offline, privacy-conscious incident aggregation."""

__version__ = '1.0.0'
