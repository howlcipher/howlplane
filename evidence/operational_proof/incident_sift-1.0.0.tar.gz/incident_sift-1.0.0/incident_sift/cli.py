"""Streaming JSONL validation, filtering, and deterministic reporting."""
import argparse
from collections import Counter
from datetime import datetime, timezone
import json
import re
import sys

from . import __version__

LEVELS = ('debug', 'info', 'warning', 'error', 'critical')
# Redact the entire label: partial replacement can leave credential fragments.
SENSITIVE = re.compile(
    r'[^\s@]+@[^\s@]+|\bbearer\b|'
    r'token|password|passwd|api[\s_.-]*key|'
    r'\bsk-[a-z0-9_-]{8,}|\bgh[pousr]_[a-z0-9_]{8,}|'
    r'\bAKIA[A-Z0-9]{16}', re.IGNORECASE)


class SafeParser(argparse.ArgumentParser):
    """Argparse's default errors echo untrusted option values."""

    def error(self, message):
        self.exit(2, 'incident-sift: invalid arguments; use --help\n')


def timestamp(value):
    """Parse an aware ISO8601 timestamp and normalize safely to UTC."""
    if type(value) is not str:
        raise ValueError('timestamp type')
    parsed = datetime.fromisoformat(value)
    if parsed.tzinfo is None or parsed.utcoffset() is None:
        raise ValueError('timezone required')
    return parsed.astimezone(timezone.utc)


def validate(value):
    if type(value) is not dict:
        raise ValueError('object required')
    for field in ('timestamp', 'source', 'category', 'level', 'message'):
        if type(value.get(field)) is not str:
            raise ValueError('string required')
    if not value['source'].strip() or not value['category'].strip():
        raise ValueError('empty label')
    if value['level'] not in LEVELS:
        raise ValueError('invalid level')
    return timestamp(value['timestamp'])


def label(value):
    return '[REDACTED]' if SENSITIVE.search(value) else value


def parse_args(argv):
    parser = SafeParser(prog='incident-sift', description=(
        'Summarize error/critical JSONL records without emitting messages.'))
    parser.add_argument('files', nargs='*',
                        help='UTF-8 JSONL paths; - is stdin')
    parser.add_argument('--version', action='version',
                        version=f'incident-sift {__version__}')
    parser.add_argument('--source', help='exact source match')
    parser.add_argument('--category', help='exact category match')
    parser.add_argument('--minimum-level', choices=LEVELS, default='debug')
    parser.add_argument('--since', help='inclusive aware ISO8601 timestamp')
    parser.add_argument('--until', help='exclusive aware ISO8601 timestamp')
    parser.add_argument('--strict', action='store_true',
                        help='exit 1 if any records are rejected')
    args = parser.parse_args(argv)
    try:
        args.since = timestamp(args.since) if args.since is not None else None
        args.until = timestamp(args.until) if args.until is not None else None
    except (ValueError, OverflowError):
        parser.error('invalid time boundary')
    if args.since and args.until and args.since > args.until:
        parser.error('reversed boundaries')
    args.files = args.files or ['-']
    if args.files.count('-') > 1:
        parser.error('stdin may only be read once')
    return args


def reject_constant(value):
    """Reject JavaScript constants even inside otherwise unused metadata."""
    raise ValueError('nonstandard JSON constant')


def consume(stream, args, counts, groups):
    for raw in stream:
        try:
            value = json.loads(raw.decode('utf-8'),
                               parse_constant=reject_constant)
            instant = validate(value)
        except (ValueError, OverflowError, RecursionError):
            counts['rejected'] += 1
            continue
        if ((args.source is not None and value['source'] != args.source)
                or (args.category is not None
                    and value['category'] != args.category)
                or LEVELS.index(value['level'])
                < LEVELS.index(args.minimum_level)
                or (args.since is not None and instant < args.since)
                or (args.until is not None and instant >= args.until)):
            counts['filtered'] += 1
            continue
        counts['accepted'] += 1
        if value['level'] in ('error', 'critical'):
            hour = instant.replace(minute=0, second=0, microsecond=0)
            key = (label(value['category']),
                   hour.isoformat().replace('+00:00', 'Z'),
                   label(value['source']))
            groups[key] += 1


def main(argv=None):
    args = parse_args(argv)
    counts = dict(accepted=0, rejected=0, filtered=0)
    groups = Counter()
    try:
        for path in args.files:
            if path == '-':
                consume(sys.stdin.buffer, args, counts, groups)
            else:
                with open(path, 'rb') as stream:
                    consume(stream, args, counts, groups)
    except (OSError, ValueError):
        # Paths and OS error strings can contain credentials; omit both.
        sys.stderr.write('incident-sift: input unavailable\n')
        return 2
    report = dict(counts=counts, groups=[
        dict(category=category, hour=hour, source=source, count=count)
        for (category, hour, source), count in sorted(groups.items())])
    try:
        sys.stdout.write(json.dumps(report, sort_keys=True, ensure_ascii=True,
                                    separators=(',', ':')) + '\n')
    except (OSError, UnicodeError):
        sys.stderr.write('incident-sift: output unavailable\n')
        return 2
    return 1 if args.strict and counts['rejected'] else 0
