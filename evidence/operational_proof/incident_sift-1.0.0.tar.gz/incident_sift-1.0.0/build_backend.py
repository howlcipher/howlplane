"""Minimal offline PEP 517 backend and deterministic source archive builder."""
import base64
import gzip
import hashlib
import io
from pathlib import Path
import tarfile
import zipfile

NAME = 'incident_sift-1.0.0'
ROOT = Path(__file__).resolve().parent
METADATA = (
    'Metadata-Version: 2.1\nName: incident-sift\nVersion: 1.0.0\n'
    'Summary: Offline deterministic JSONL incident summaries\n'
    'Requires-Python: >=3.11\nDescription-Content-Type: text/markdown\n\n'
)


def source_files():
    # Explicit allowlist excludes VCS state, local data, caches and artifacts.
    names = ['pyproject.toml', 'build_backend.py', 'README.md']
    for directory, pattern in [('incident_sift', '*.py'),
                               ('tests', 'test_*.py'),
                               ('scripts', '*.sh')]:
        names.extend(str(p.relative_to(ROOT))
                     for p in (ROOT / directory).glob(pattern) if p.is_file())
    return sorted(names)


def build_sdist(sdist_directory, config_settings=None):
    filename = NAME + '.tar.gz'
    destination = Path(sdist_directory)
    destination.mkdir(parents=True, exist_ok=True)
    with (destination / filename).open('wb') as output:
        with gzip.GzipFile(filename='', mode='wb', fileobj=output,
                           mtime=0) as compressed:
            with tarfile.open(fileobj=compressed, mode='w',
                              format=tarfile.USTAR_FORMAT) as archive:
                for name in sorted(source_files() + ['PKG-INFO']):
                    if name == 'PKG-INFO':
                        data = METADATA.encode('utf-8')
                    else:
                        data = (ROOT / name).read_bytes()
                    info = tarfile.TarInfo(NAME + '/' + name)
                    info.size = len(data)
                    info.mode = 0o755 if name.startswith('scripts/') else 0o644
                    info.mtime = 0
                    archive.addfile(info, io.BytesIO(data))
    return filename


def build_wheel(wheel_directory, config_settings=None,
                metadata_directory=None):
    filename = NAME + '-py3-none-any.whl'
    destination = Path(wheel_directory)
    destination.mkdir(parents=True, exist_ok=True)
    entries = {str(p.relative_to(ROOT)): p.read_bytes()
               for p in sorted((ROOT / 'incident_sift').glob('*.py'))}
    prefix = NAME + '.dist-info/'
    entries[prefix + 'METADATA'] = (
        METADATA + (ROOT / 'README.md').read_text(encoding='utf-8')
    ).encode('utf-8')
    entries[prefix + 'WHEEL'] = (
        'Wheel-Version: 1.0\nGenerator: incident-sift\n'
        'Root-Is-Purelib: true\nTag: py3-none-any\n'
    ).encode()
    entries[prefix + 'entry_points.txt'] = (
        '[console_scripts]\nincident-sift = incident_sift.cli:main\n'
    ).encode()
    records = []
    for name, data in sorted(entries.items()):
        digest = base64.urlsafe_b64encode(hashlib.sha256(data).digest())
        encoded = digest.decode().rstrip("=")
        records.append(f'{name},sha256={encoded},{len(data)}')
    records.append(prefix + 'RECORD,,')
    entries[prefix + 'RECORD'] = ('\n'.join(records) + '\n').encode()
    with zipfile.ZipFile(destination / filename, 'w') as archive:
        for name, data in sorted(entries.items()):
            info = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
            info.create_system = 3
            info.external_attr = 0o100644 << 16
            archive.writestr(info, data)
    return filename


if __name__ == '__main__':
    print(build_sdist(ROOT / 'dist'))
