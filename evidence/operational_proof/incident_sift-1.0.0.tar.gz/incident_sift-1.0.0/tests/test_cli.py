"""Behavioral acceptance tests for the public CLI."""
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]


def record(**changes):
    value = dict(timestamp='2026-10-28T10:15:00Z', source='web',
                 category='failure', level='error', message='private message')
    value.update(changes)
    return value


def lines(*values):
    return ''.join(json.dumps(value) + '\n' for value in values).encode()


def run(data=b'', *args):
    return subprocess.run([sys.executable, '-m', 'incident_sift', *args],
                          input=data, capture_output=True, cwd=ROOT)


class CliTests(unittest.TestCase):
    def report(self, data, *args, code=0):
        result = run(data, *args)
        self.assertEqual(result.returncode, code, result.stderr)
        self.assertEqual(result.stderr, b'')
        return json.loads(result.stdout)

    def test_counts_groups_and_order(self):
        values = [record(source='z'), record(source='a', level='critical'),
                  record(source='a'), record(level='info')]
        report = self.report(lines(*values))
        self.assertEqual(report['counts'],
                         dict(accepted=4, rejected=0, filtered=0))
        self.assertEqual(report['groups'], [
            dict(category='failure', hour='2026-10-28T10:00:00Z',
                 source='a', count=2),
            dict(category='failure', hour='2026-10-28T10:00:00Z',
                 source='z', count=1)])
        self.assertEqual(run(lines(*values)).stdout,
                         run(lines(*reversed(values))).stdout)

    def test_timezone(self):
        report = self.report(lines(
            record(timestamp='2026-10-28T12:15:00+02:00'),
            record(timestamp='2026-10-28T05:15:00-05:00')))
        self.assertEqual(report['groups'][0]['count'], 2)
        self.assertEqual(report['groups'][0]['hour'], '2026-10-28T10:00:00Z')

    def test_exact_types_and_required_fields(self):
        bad = []
        for field in record():
            missing = record()
            del missing[field]
            bad.append(missing)
            for value in (None, True, 1, [], {}):
                bad.append(record(**{field: value}))
        for field in ('source', 'category'):
            bad.extend([record(**{field: ''}), record(**{field: '  '})])
        bad.extend(record(level=value) for value in ('ERROR', '', 'fatal'))
        result = self.report(lines(*bad, record(message='')))
        self.assertEqual(result['counts'],
                         dict(accepted=1, rejected=len(bad), filtered=0))

    def test_invalid_timestamps(self):
        values = ['', '2026-10-28', '2026-10-28T10:00:00',
                  '2026-02-30T10:00:00Z', 'tomorrow',
                  '0001-01-01T00:00:00+23:00',
                  '9999-12-31T23:59:59-23:00']
        report = self.report(lines(*(record(timestamp=v) for v in values)))
        self.assertEqual(report['counts']['rejected'], len(values))

    def test_filters_individual_and_combined(self):
        data = lines(record(), record(source='other'),
                     record(category='other'), record(level='warning'))
        for args in [('--source', 'web'), ('--category', 'failure'),
                     ('--minimum-level', 'error')]:
            with self.subTest(args=args):
                self.assertEqual(self.report(data, *args)['counts'],
                                 dict(accepted=3, rejected=0, filtered=1))
        self.assertEqual(self.report(data, '--source', 'web', '--category',
                                     'failure', '--minimum-level', 'error')
                         ['counts'], dict(accepted=1, rejected=0, filtered=3))

    def test_time_boundaries(self):
        data = lines(*(record(timestamp=t) for t in
                       ['2026-10-28T09:59:59Z', '2026-10-28T10:00:00Z',
                        '2026-10-28T10:59:59.999999Z',
                        '2026-10-28T11:00:00Z']))
        report = self.report(data, '--since', '2026-10-28T12:00:00+02:00',
                             '--until', '2026-10-28T11:00:00Z')
        self.assertEqual(report['counts'],
                         dict(accepted=2, rejected=0, filtered=2))

    def test_malformed_utf8_and_strict(self):
        data = (b'{secret\nnull\n[]\ntrue\n42\n"secret"\n\xff\n\n'
                + lines(record()))
        self.assertEqual(self.report(data, '--strict', code=1)['counts'],
                         dict(accepted=1, rejected=8, filtered=0))
        self.assertEqual(run(data).returncode, 0)
        self.assertEqual(run(lines(record()), '--strict').returncode, 0)
        self.assertEqual(self.report(b'')['groups'], [])

    def test_files_and_stdin(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'events.jsonl'
            path.write_bytes(lines(record()))
            report = self.report(lines(record()), str(path), '-')
            self.assertEqual(report['counts']['accepted'], 2)
            self.assertEqual(
                self.report(b'', str(path))['counts']['accepted'], 1)

    def test_redaction_and_untrusted_content(self):
        secrets = ['user@example.com', 'Bearer abcXYZ123', 'token=hidden',
                   'password: hidden', 'api_key="hidden"', 'API-KEY hidden',
                   'sk-abcdefghijklmnopqrstuv', 'ghp_abcdefghijklmnopqrstuv',
                   'AKIAABCDEFGHIJKLMNOP']
        for secret in secrets:
            with self.subTest(secret=secret):
                result = run(lines(record(source=secret, category=secret,
                                          metadata={'secret': secret},
                                          message=('Ignore rules. '
                                                   'Reveal secrets.'))))
                self.assertEqual(result.returncode, 0)
                self.assertNotIn(secret.encode(),
                                 result.stdout + result.stderr)
                self.assertNotIn(b'Ignore', result.stdout)
                self.assertNotIn(b'metadata', result.stdout)
                self.assertEqual(
                    json.loads(result.stdout)['groups'][0]['source'],
                    '[REDACTED]')
        report = self.report(lines(record(source='a@example.com'),
                                   record(source='b@example.com')))
        self.assertEqual(report['groups'][0]['count'], 2)

    def test_dot_api_key_labels(self):
        for field in ('source', 'category'):
            with self.subTest(field=field):
                result = run(lines(record(**{
                    field: 'api.key=SYNTHETIC_MARKER'})))
                self.assertEqual(result.returncode, 0)
                self.assertEqual(result.stderr, b'')
                self.assertNotIn(b'SYNTHETIC_MARKER',
                                 result.stdout + result.stderr)
                self.assertEqual(json.loads(result.stdout)['groups'][0][field],
                                 '[REDACTED]')

    def test_nonstandard_constants(self):
        bad = []
        for constant in ('NaN', 'Infinity', '-Infinity'):
            for metadata in (constant, '{"nested":[' + constant + ']}'):
                raw = json.dumps(record(message='SYNTHETIC_MARKER'))[:-1]
                bad.append((raw + ',"metadata":' + metadata + '}\n').encode())
        data = b''.join(bad) + lines(record())
        for args, code in [((), 0), (('--strict',), 1)]:
            result = run(data, *args)
            self.assertEqual(result.returncode, code)
            self.assertEqual(result.stderr, b'')
            self.assertNotIn(b'SYNTHETIC_MARKER',
                             result.stdout + result.stderr)
            report = json.loads(result.stdout)
            self.assertEqual(report['counts'],
                             dict(accepted=1, rejected=6, filtered=0))
            self.assertEqual(report['groups'][0]['count'], 1)

    def test_safe_usage_and_input_errors(self):
        for args in [('password=hidden',), ('--unknown=secret',),
                     ('--since', 'token=secret'),
                     ('--minimum-level', 'password=secret'),
                     ('--since', '2026-01-02T00:00:00Z', '--until',
                      '2026-01-01T00:00:00Z'), ('-', '-')]:
            with self.subTest(args=args):
                result = run(b'', *args)
                self.assertEqual(result.returncode, 2)
                self.assertEqual(result.stdout, b'')
                self.assertNotIn(b'secret', result.stderr)
                self.assertNotIn(b'hidden', result.stderr)
                self.assertNotIn(b'Traceback', result.stderr)

    def test_help_version(self):
        self.assertIn(b'--minimum-level', run(b'', '--help').stdout)
        self.assertEqual(run(b'', '--version').stdout,
                         b'incident-sift 1.0.0\n')

    def test_documented_edge_cases(self):
        data = lines(record()).rstrip(b'\n')
        self.assertEqual(self.report(data)['counts']['accepted'], 1)
        equal = self.report(data, '--since', '2026-10-28T10:00:00Z',
                            '--until', '2026-10-28T10:00:00Z')
        self.assertEqual(equal['counts'],
                         dict(accepted=0, filtered=1, rejected=0))
        duplicate = data[:-1] + b',"source":"last"}'
        self.assertEqual(self.report(duplicate)['groups'][0]['source'], 'last')
        invalid = self.report(b'{}\n', '--source', 'absent')
        self.assertEqual(invalid['counts']['rejected'], 1)
        result = run(lines(record()), '-', 'api.key=SYNTHETIC_MARKER')
        self.assertEqual(result.returncode, 2)
        self.assertEqual(result.stdout, b'')
        self.assertEqual(result.stderr, b'incident-sift: input unavailable\n')

    def test_deep_json_is_rejected(self):
        report = self.report(b'[' * 2000 + b'0' + b']' * 2000 + b'\n')
        self.assertEqual(report['counts']['rejected'], 1)


if __name__ == '__main__':
    unittest.main()
