"""Verify the documented offline build and installation workflow."""
import hashlib
import os
from pathlib import Path
import subprocess
import tarfile
import tempfile
import unittest
import venv

ROOT = Path(__file__).resolve().parents[1]


class PackagingTests(unittest.TestCase):
    def test_reproducible_build_and_clean_install(self):
        def execute(args, cwd, **kwargs):
            result = subprocess.run(args, cwd=cwd, capture_output=True,
                                    **kwargs)
            self.assertEqual(result.returncode, 0,
                             (result.stdout, result.stderr))
            return result

        execute(['bash', 'scripts/build.sh'], ROOT)
        artifact = ROOT / 'dist' / 'incident_sift-1.0.0.tar.gz'
        first = artifact.read_bytes()
        execute(['bash', 'scripts/build.sh'], ROOT)
        self.assertEqual(hashlib.sha256(first).digest(),
                         hashlib.sha256(artifact.read_bytes()).digest())
        with tempfile.TemporaryDirectory(dir=ROOT) as directory:
            work = Path(directory)
            with tarfile.open(artifact) as archive:
                for member in archive.getmembers():
                    self.assertTrue(member.isfile())
                    self.assertEqual(member.mtime, 0)
                    self.assertEqual(member.uid, 0)
                    self.assertEqual(member.gid, 0)
                    self.assertNotIn('..', Path(member.name).parts)
                    self.assertFalse(Path(member.name).is_absolute())
                archive.extractall(work)
            source = work / 'incident_sift-1.0.0'
            venv.EnvBuilder(with_pip=True).create(work / 'venv')
            python = work / 'venv/bin/python'
            environment = os.environ.copy()
            environment.pop('PYTHONPATH', None)
            environment['PIP_CONFIG_FILE'] = os.devnull
            execute([str(python), '-m', 'pip', 'install', '--no-index',
                     '--no-deps', '--no-build-isolation', '--no-cache-dir',
                     '--disable-pip-version-check', str(source)], work,
                    env=environment)
            command = work / 'venv/bin/incident-sift'
            result = execute([str(command), '--version'], work,
                             env=environment)
            self.assertEqual(result.stdout, b'incident-sift 1.0.0\n')
            result = execute([str(command)], work, input=b'', env=environment)
            self.assertEqual(result.stdout,
                             b'{"counts":{"accepted":0,"filtered":0,'
                             b'"rejected":0},"groups":[]}\n')
            execute([str(command), '--help'], work, env=environment)
